<?php
/**
 * Front template — the complete Frosty Foods website.
 * Content, design and SEO come from the built-in dashboard (option "frosty_content").
 *
 * @package Frosty_Foods
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$frosty_content = frosty_get_content();
$frosty_seo     = ( isset( $frosty_content['seo'] ) && is_array( $frosty_content['seo'] ) ) ? $frosty_content['seo'] : array();
$frosty_title   = ! empty( $frosty_seo['titleEn'] ) ? $frosty_seo['titleEn'] : 'Frosty Foods — IQF Fruits & Vegetables from Egypt to the World';
$frosty_desc    = ! empty( $frosty_seo['descEn'] ) ? $frosty_seo['descEn'] : 'Frosty Foods is a certified Egyptian manufacturer and exporter of IQF frozen fruits and vegetables — retail packs, food service, private label and industrial formats shipped to 50+ countries.';
$frosty_base    = trailingslashit( get_template_directory_uri() );
$frosty_assets  = esc_url( $frosty_base . 'assets/' );
?><!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo esc_html( $frosty_title ); ?></title>
<meta name="description" id="metaDesc" content="<?php echo esc_attr( $frosty_desc ); ?>">
<link rel="icon" type="image/png" href="<?php echo $frosty_assets; ?>img/favicon.png" id="favicon">
<link rel="stylesheet" href="<?php echo $frosty_assets; ?>cms/cms.css">
<script>window.FROSTY_BASE=<?php echo wp_json_encode( $frosty_base ); ?>;window.FROSTY_WP=<?php echo wp_json_encode( array( 'rest' => esc_url_raw( rest_url( 'frosty/v1/' ) ), 'content' => (object) $frosty_content ), JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ); ?>;</script>
<script src="<?php echo $frosty_assets; ?>cms/cms.js"></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Inter:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500&family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root{
  --navy-950:#041221;--navy-900:#061A2E;--navy-850:#08223B;--navy-800:#0A2A47;--navy:#0C3352;--navy-600:#15476F;--navy-500:#2A5D86;
  --ice:#39B9E4;--ice-300:#8FD6F0;--ice-100:#DDF2FB;--ice-50:#F0F8FC;
  --green:#3FBE23;--green-600:#2C9416;
  --paper:#F5F7FA;--white:#fff;--ink:#0A1A2A;--ink-70:#3C4E61;--ink-50:#6B7C8E;--line:#DEE5EC;--line-dark:rgba(255,255,255,.12);
  --f-display:"Manrope",system-ui,sans-serif;--f-ar:"IBM Plex Sans Arabic",sans-serif;--f-body:"Inter",system-ui,sans-serif;--f-mono:"IBM Plex Mono",ui-monospace,monospace;
  --ease:cubic-bezier(.22,.8,.2,1);--ease-io:cubic-bezier(.65,0,.35,1);
  --r:6px;--r-lg:10px;
  --shadow:0 1px 2px rgba(10,26,42,.05),0 12px 32px -14px rgba(10,26,42,.18);
  --shadow-lift:0 2px 4px rgba(10,26,42,.06),0 28px 56px -22px rgba(10,26,42,.32);
  --wrap:1180px;--gut:clamp(24px,6vw,88px);
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth;-webkit-text-size-adjust:100%}
body{font-family:var(--f-body);color:var(--ink);background:var(--white);line-height:1.6;font-size:16px;-webkit-font-smoothing:antialiased;overflow-x:hidden}
html[lang="ar"] body{font-family:var(--f-ar),var(--f-body)}
html[lang="ar"] :is(h1,h2,h3,h4,.h1,.h2,.fig b,.btn){font-family:var(--f-ar),sans-serif;letter-spacing:0!important}
img{max-width:100%;display:block}
a{color:inherit;text-decoration:none}
button{font:inherit;cursor:pointer;border:0;background:none;color:inherit}
input,select,textarea{font:inherit;color:inherit}
.wrap{max-width:var(--wrap);margin-inline:auto;padding-inline:var(--gut)}
[dir="ltr"]{unicode-bidi:isolate;direction:ltr}
.sr{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)}
::selection{background:var(--ice);color:var(--navy-900)}

/* ---------- type ---------- */
.h1{font-family:var(--f-display);font-weight:700;font-size:clamp(2.3rem,4.3vw,3.9rem);line-height:1.06;letter-spacing:-.035em}
.h2{font-family:var(--f-display);font-weight:700;font-size:clamp(1.7rem,2.6vw,2.45rem);line-height:1.08;letter-spacing:-.03em;color:var(--navy-900)}
.h3{font-family:var(--f-display);font-weight:700;font-size:clamp(1.3rem,1.8vw,1.6rem);line-height:1.2;letter-spacing:-.02em}
.lead{font-size:clamp(.97rem,1.05vw,1.06rem);color:var(--ink-70);line-height:1.7;max-width:60ch}
.dark .h2,.dark .h3{color:#fff}.dark .lead{color:rgba(255,255,255,.72)}
.mono{font-family:var(--f-mono);font-size:.74rem;letter-spacing:.08em;text-transform:uppercase}
html[lang="ar"] .mono{font-family:var(--f-ar);letter-spacing:0;font-size:.82rem}
.sh{display:flex;align-items:center;gap:14px;margin-bottom:22px;color:var(--navy-500)}
.sh .idx{font-family:var(--f-mono);font-size:.74rem;color:var(--ice);font-weight:500}
.sh .rule{height:1px;width:48px;background:currentColor;opacity:.4}
.dark .sh{color:var(--ice-300)}
.sec{padding-block:clamp(72px,8vw,118px);position:relative}
.sec-head{display:grid;grid-template-columns:1.1fr 1fr;gap:48px;align-items:end;margin-bottom:clamp(34px,4vw,56px)}
.accent{color:var(--ice)}
.dark{background:var(--navy-900);color:#fff}

/* ---------- buttons ---------- */
.btn{display:inline-flex;align-items:center;gap:10px;padding:15px 26px;border-radius:var(--r);font-family:var(--f-display);font-weight:700;font-size:.95rem;letter-spacing:-.005em;transition:background .3s,color .3s,border-color .3s,transform .3s var(--ease),box-shadow .3s;white-space:nowrap}
.btn svg{width:16px;height:16px;flex:none;transition:transform .3s var(--ease)}
.btn:hover svg{transform:translateX(3px)}
html[dir="rtl"] .btn svg{transform:scaleX(-1)}html[dir="rtl"] .btn:hover svg{transform:scaleX(-1) translateX(3px)}
.btn-primary{background:var(--ice);color:var(--navy-900)}
.btn-primary:hover{background:#fff;box-shadow:0 10px 30px -10px rgba(57,185,228,.7)}
.btn-navy{background:var(--navy);color:#fff}.btn-navy:hover{background:var(--navy-900)}
.btn-ghost{border:1px solid rgba(255,255,255,.32);color:#fff}.btn-ghost:hover{background:rgba(255,255,255,.1);border-color:#fff}
.btn-line{border:1px solid var(--line);color:var(--navy)}.btn-line:hover{border-color:var(--navy);background:var(--ice-50)}

/* ---------- reveal motion ---------- */
.rv{opacity:0;transform:translateY(26px);transition:opacity 1s var(--ease),transform 1s var(--ease)}
.rv.in{opacity:1;transform:none}
.d1{transition-delay:.08s}.d2{transition-delay:.16s}.d3{transition-delay:.24s}.d4{transition-delay:.32s}.d5{transition-delay:.4s}

/* ---------- utility bar + nav ---------- */
.util{background:var(--navy-950);color:rgba(255,255,255,.7);font-size:.78rem;position:relative;z-index:60}
.util .wrap{display:flex;justify-content:space-between;align-items:center;height:38px;gap:20px}
.util-l,.util-r{display:flex;align-items:center;gap:22px}
.util a,.util span{white-space:nowrap}.util a{display:inline-flex;align-items:center;gap:7px;transition:color .2s}.util a:hover{color:#fff}
.util svg{width:13px;height:13px;opacity:.7}
.util-tag{color:var(--ice-300);font-family:var(--f-mono);font-size:.7rem;letter-spacing:.1em;text-transform:uppercase}
html[lang="ar"] .util-tag{font-family:inherit;letter-spacing:0}
.lang{display:flex;border:1px solid rgba(255,255,255,.18);border-radius:4px;overflow:hidden}
.lang button{padding:3px 10px;font-size:.72rem;font-weight:600;color:rgba(255,255,255,.65)}
.lang button.on{background:var(--ice);color:var(--navy-900)}
.nav{position:sticky;top:0;z-index:50;transition:background .4s,box-shadow .4s,border-color .4s;border-bottom:1px solid transparent;margin-bottom:-84px}
.nav .wrap{display:flex;align-items:center;height:84px;gap:34px}
.nav-logo img{height:48px;width:auto;transition:height .3s}
.nav-links{display:flex;gap:30px;margin-inline-start:auto}
.nav-links a{font-size:.9rem;font-weight:500;color:rgba(255,255,255,.86);position:relative;padding-block:6px;transition:color .25s}
.nav-links a::after{content:"";position:absolute;inset-inline:0;bottom:0;height:1.5px;background:var(--ice);transform:scaleX(0);transform-origin:left;transition:transform .35s var(--ease)}
.nav-links a:hover::after,.nav-links a.act::after{transform:scaleX(1)}
.nav-cta{position:relative;padding:12px 20px;font-size:.88rem}
.nav-cta .cnt{position:absolute;top:-8px;inset-inline-end:-8px;min-width:22px;height:22px;border-radius:11px;background:var(--green);color:#fff;font-size:.72rem;display:grid;place-items:center;padding-inline:6px;transform:scale(0);transition:transform .35s var(--ease)}
.nav-cta .cnt.on{transform:scale(1)}
.nav.solid{background:rgba(255,255,255,.96);backdrop-filter:blur(14px);border-bottom-color:var(--line);box-shadow:0 8px 30px -20px rgba(10,26,42,.35)}
.nav.solid .nav-links a{color:var(--ink-70)}.nav.solid .nav-links a:hover{color:var(--navy)}
.nav.solid .nav-logo img{height:42px}
.nav.solid .nav-cta{background:var(--navy);color:#fff}
.burger{display:none;width:44px;height:44px;border-radius:var(--r);border:1px solid rgba(255,255,255,.3);flex-direction:column;justify-content:center;align-items:center;gap:5px}
.burger span{width:18px;height:1.5px;background:currentColor;transition:transform .3s,opacity .3s}
.nav:not(.solid) .burger{color:#fff}.nav.solid .burger{border-color:var(--line);color:var(--navy)}
.burger.x span:nth-child(1){transform:translateY(6.5px) rotate(45deg)}.burger.x span:nth-child(2){opacity:0}.burger.x span:nth-child(3){transform:translateY(-6.5px) rotate(-45deg)}
.mmenu{position:fixed;inset:0;z-index:45;background:var(--navy-900);padding:140px var(--gut) 40px;display:flex;flex-direction:column;gap:6px;opacity:0;pointer-events:none;transition:opacity .35s}
.mmenu.open{opacity:1;pointer-events:auto}
.mmenu a{font-family:var(--f-display);font-size:1.7rem;font-weight:700;color:#fff;padding:10px 0;border-bottom:1px solid var(--line-dark)}
.mmenu .btn{margin-top:22px;justify-content:center;font-size:1rem;border:0}

/* ---------- hero ---------- */
.hero{position:relative;min-height:max(680px,calc(100svh - 38px));color:#fff;display:flex;flex-direction:column;overflow:hidden;background:var(--navy-900)}
.hero-media{position:absolute;inset:0}
.hero-media video{width:100%;height:100%;object-fit:cover;transform:scale(1.08);animation:heroZoom 2.8s var(--ease) forwards}
@keyframes heroZoom{to{transform:scale(1)}}
.hero-media::after{content:"";position:absolute;inset:0;background:
  radial-gradient(ellipse 62% 55% at 50% 46%,rgba(4,18,33,.78) 0%,rgba(4,18,33,.84) 55%,rgba(4,18,33,.9) 100%),
  linear-gradient(0deg,rgba(4,18,33,.95) 0%,rgba(4,18,33,0) 35%)}
.hero-body{position:relative;flex:1;display:flex;align-items:center;justify-content:center;padding-top:130px;padding-bottom:36px}
.hero-copy{max-width:820px;margin-inline:auto;text-align:center;display:flex;flex-direction:column;align-items:center}
.hero-kicker{display:inline-flex;align-items:center;gap:10px;padding:7px 14px 7px 11px;border:1px solid rgba(255,255,255,.18);border-radius:40px;background:rgba(255,255,255,.06);backdrop-filter:blur(8px);font-size:.78rem;color:rgba(255,255,255,.86);margin-bottom:26px}
.hero-kicker .dot{width:7px;height:7px;border-radius:50%;background:var(--green);animation:ping 2.4s infinite}
@keyframes ping{0%{box-shadow:0 0 0 0 rgba(63,190,35,.55)}70%{box-shadow:0 0 0 10px rgba(63,190,35,0)}100%{box-shadow:0 0 0 0 rgba(63,190,35,0)}}
.hero .h1{font-size:clamp(2.5rem,4.8vw,4.3rem);line-height:1.04;text-shadow:0 2px 28px rgba(4,18,33,.55)}
.hero .h1 em{font-style:normal;color:var(--ice)}
.hero .h1 .ln{display:block;overflow:hidden;padding-bottom:.06em}
.hero .h1 .ln>span{display:block;transform:translateY(105%);animation:lineUp 1.1s var(--ease) forwards}
.hero .h1 .ln:nth-child(2)>span{animation-delay:.12s}
@keyframes lineUp{to{transform:none}}
.hero .lead{color:rgba(255,255,255,.78);margin:22px auto 0;max-width:52ch;text-align:center}
.hero-ctas{display:flex;gap:12px;flex-wrap:wrap;justify-content:center;margin-top:32px}
.fade-up{opacity:0;animation:fadeUp 1s var(--ease) forwards}
.fu1{animation-delay:.45s}.fu2{animation-delay:.6s}.fu3{animation-delay:.75s}.fu4{animation-delay:.95s}
@keyframes fadeUp{from{opacity:0;transform:translateY(18px)}to{opacity:1;transform:none}}
.hero-figs{position:relative;border-top:1px solid rgba(255,255,255,.12);background:rgba(4,18,33,.45);backdrop-filter:blur(6px)}
.figs{display:grid;grid-template-columns:repeat(4,1fr);max-width:900px;margin-inline:auto}
.fig{padding:20px 12px;text-align:center;border-inline-end:1px solid rgba(255,255,255,.1)}
.fig:last-child{border-inline-end:0}
.fig b{display:block;font-family:var(--f-display);font-size:clamp(1.5rem,2vw,1.9rem);font-weight:700;letter-spacing:-.03em;line-height:1}
.fig b small{font-size:.55em;color:var(--ice);margin-inline-start:2px}
.fig>span{display:block;margin-top:6px;font-size:.76rem;color:rgba(255,255,255,.6)}
.season-now{display:flex;align-items:center;justify-content:center;gap:10px;flex-wrap:wrap;padding:11px 0 13px;border-top:1px solid rgba(255,255,255,.08);font-size:.82rem;color:rgba(255,255,255,.8);text-align:center}
.season-now .mono{color:var(--green);display:inline-flex;align-items:center;gap:7px}
.season-now .mono::before{content:"";width:6px;height:6px;border-radius:50%;background:var(--green)}
.season-now a{color:var(--ice-300);text-decoration:underline;text-underline-offset:3px}

/* ---------- trust strip ---------- */
.trust{border-bottom:1px solid var(--line);background:#fff}
.trust .wrap{display:grid;grid-template-columns:auto 1fr;align-items:center;gap:32px;padding-block:24px}
.trust-certs{display:flex;align-items:center;gap:12px}
.trust-certs img{height:70px;width:70px;object-fit:contain;padding:6px;background:#fff;border:1px solid var(--line);border-radius:var(--r);transition:transform .3s var(--ease),box-shadow .3s}
.trust-certs img:hover{transform:translateY(-3px);box-shadow:var(--shadow)}
.trust-label{font-size:.78rem;color:var(--ink-50);max-width:150px;line-height:1.35;margin-inline-end:10px}
.marquee{overflow:hidden;mask-image:linear-gradient(90deg,transparent,#000 8%,#000 92%,transparent);border-inline-start:1px solid var(--line)}
.mq-track{display:flex;width:max-content;animation:mq 38s linear infinite}
.marquee:hover .mq-track{animation-play-state:paused}
@keyframes mq{to{transform:translateX(-50%)}}
html[dir="rtl"] .mq-track{animation-name:mqr}@keyframes mqr{to{transform:translateX(50%)}}
.mq-item{display:flex;align-items:baseline;gap:10px;padding-inline:34px;white-space:nowrap;font-family:var(--f-display);font-weight:800;font-size:1.05rem;color:var(--navy);letter-spacing:.02em}
.mq-item small{font-family:var(--f-mono);font-weight:400;font-size:.68rem;color:var(--ink-50);letter-spacing:.08em;text-transform:uppercase}
.mq-item::before{content:"";width:5px;height:5px;background:var(--ice);transform:rotate(45deg);align-self:center}

/* ---------- company ---------- */
.company-grid{display:grid;grid-template-columns:1.05fr 1fr;gap:clamp(36px,5vw,72px);align-items:stretch}
.values{margin-top:30px;display:grid;grid-template-columns:1fr 1fr;border-top:1px solid var(--line)}
.value{display:grid;grid-template-columns:36px 1fr;gap:6px;padding-block:18px;padding-inline:0 16px;border-bottom:1px solid var(--line)}
.value:nth-child(odd){border-inline-end:1px solid var(--line)}.value:nth-child(even){padding-inline-start:18px}
.value .n{font-family:var(--f-mono);font-size:.78rem;color:var(--ice);padding-top:3px}
.value b{font-family:var(--f-display);font-size:1.05rem;color:var(--navy-900)}
.value p{font-size:.92rem;color:var(--ink-70);margin-top:2px}
.facility{position:relative;border-radius:var(--r-lg);overflow:hidden;min-height:420px;height:100%;box-shadow:var(--shadow-lift)}
.facility img{position:absolute;inset-inline:0;top:-9%;width:100%;height:118%;object-fit:cover;will-change:transform}
.facility::after{content:"";position:absolute;inset:0;background:linear-gradient(0deg,rgba(4,18,33,.88) 0%,rgba(4,18,33,0) 50%)}
.facility figcaption{position:absolute;inset-inline:0;bottom:0;padding:28px;z-index:2;color:#fff;display:flex;justify-content:space-between;align-items:end;gap:18px}
.facility figcaption b{font-family:var(--f-display);font-size:1.25rem;display:block}
.facility figcaption span{font-size:.85rem;color:rgba(255,255,255,.72)}
.pin{position:absolute;top:24px;inset-inline-start:24px;z-index:2;background:rgba(255,255,255,.94);color:var(--navy);padding:8px 13px;border-radius:40px;font-size:.78rem;font-weight:600;display:flex;align-items:center;gap:8px}
.pin i{width:8px;height:8px;border-radius:50%;background:var(--green);animation:ping 2.4s infinite}
.facts{display:grid;grid-template-columns:repeat(4,1fr);margin-top:clamp(44px,5vw,72px);border:1px solid var(--line);border-radius:var(--r-lg);background:var(--paper)}
.fact{padding:22px 24px;border-inline-end:1px solid var(--line)}
.fact:last-child{border-inline-end:0}
.fact .mono{color:var(--ink-50)}
.fact b{display:block;font-family:var(--f-display);font-size:1.12rem;color:var(--navy-900);margin-top:8px;line-height:1.3}
.fact p{font-size:.85rem;color:var(--ink-70);margin-top:4px}

/* ---------- production ---------- */
.production{overflow:hidden;background:var(--navy-950)}
.prod-bg{position:absolute;inset:-10% 0;background:var(--img-prod,url(<?php echo $frosty_assets; ?>img/factory/production-line.webp)) center/cover no-repeat;opacity:.34;will-change:transform}
.production::before{content:"";position:absolute;inset:0;z-index:1;background:linear-gradient(180deg,var(--navy-950) 0%,rgba(4,18,33,.55) 30%,rgba(4,18,33,.72) 70%,var(--navy-950) 100%)}
.production>.wrap{position:relative;z-index:2}
.iqf-row{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:clamp(64px,8vw,110px)}
.iqf-card{border:1px solid var(--line-dark);border-radius:var(--r-lg);padding:30px;background:rgba(255,255,255,.035);backdrop-filter:blur(10px);display:grid;grid-template-columns:150px 1fr;gap:26px;align-items:center}
.iqf-card.good{border-color:rgba(57,185,228,.45);background:linear-gradient(135deg,rgba(57,185,228,.12),rgba(255,255,255,.03))}
.iqf-card .mono{color:rgba(255,255,255,.55)}.iqf-card.good .mono{color:var(--ice)}
.iqf-card b{display:block;font-family:var(--f-display);font-size:1.2rem;margin:6px 0 6px}
.iqf-card p{font-size:.9rem;color:rgba(255,255,255,.68)}
.pieces{aspect-ratio:1;border-radius:var(--r);background:rgba(255,255,255,.04);border:1px solid var(--line-dark);position:relative;overflow:hidden}
.pieces i{position:absolute;width:13%;height:13%;border-radius:40%;background:#6FA85A}
.iqf-card.good .pieces i{background:var(--ice-300);box-shadow:0 0 0 2px rgba(255,255,255,.08);animation:float 4s ease-in-out infinite}
.iqf-card.bad .pieces i{background:rgba(143,214,240,.35)}
.iqf-card.bad .pieces::after{content:"";position:absolute;inset:18%;border-radius:18%;background:rgba(143,214,240,.18);border:1px solid rgba(143,214,240,.3)}
@keyframes float{50%{transform:translateY(-4px)}}
.process{position:relative;display:grid;grid-template-columns:repeat(6,1fr);gap:0}
.process-line{position:absolute;top:27px;inset-inline:8.33%;height:1px;background:var(--line-dark)}
.process-line i{position:absolute;inset:0;background:linear-gradient(90deg,var(--ice),var(--green));transform-origin:left;transform:scaleX(var(--p,0));transition:transform .2s linear}
html[dir="rtl"] .process-line i{transform-origin:right}
.pstep{text-align:center;padding-inline:12px;position:relative}
.pstep .node{width:54px;height:54px;border-radius:50%;margin:0 auto 22px;display:grid;place-items:center;background:var(--navy-900);border:1px solid rgba(255,255,255,.2);color:var(--ice-300);transition:border-color .5s,background .5s,color .5s}
.pstep.on .node{border-color:var(--ice);background:var(--navy-800);color:#fff;box-shadow:0 0 0 6px rgba(57,185,228,.08)}
.pstep .node svg{width:22px;height:22px}
.pstep .mono{color:var(--ice-300);opacity:.8}
.pstep b{display:block;font-family:var(--f-display);font-size:1.02rem;margin:6px 0 6px}
.pstep p{font-size:.84rem;color:rgba(255,255,255,.62);line-height:1.55}
.cold-note{margin-top:64px;display:flex;align-items:center;justify-content:center;gap:16px;flex-wrap:wrap;font-size:.95rem;color:rgba(255,255,255,.78);text-align:center}
.cold-note .cn-chip{font-family:var(--f-mono);border:1px solid rgba(57,185,228,.5);color:var(--ice);border-radius:40px;padding:6px 14px}

/* ---------- products ---------- */
.products{background:var(--paper)}
.p-tools{display:flex;justify-content:space-between;align-items:center;gap:20px;flex-wrap:wrap;margin-bottom:34px}
.tabs{display:flex;gap:6px;flex-wrap:wrap}
.tab{padding:10px 16px;border-radius:var(--r);border:1px solid var(--line);background:#fff;font-size:.86rem;font-weight:600;color:var(--ink-70);transition:all .25s}
.tab small{font-family:var(--f-mono);color:var(--ink-50);margin-inline-start:6px;font-weight:400}
.tab:hover{border-color:var(--navy-500);color:var(--navy)}
.tab.on{background:var(--navy);border-color:var(--navy);color:#fff}.tab.on small{color:var(--ice-300)}
.face-switch{display:flex;align-items:center;gap:12px;font-size:.84rem;color:var(--ink-70)}
.seg{display:inline-flex;background:#fff;border:1px solid var(--line);border-radius:var(--r);padding:3px}
.seg button{padding:7px 14px;border-radius:4px;font-size:.8rem;font-weight:600;color:var(--ink-50);transition:all .25s}
.seg button.on{background:var(--ice-100);color:var(--navy)}
.p-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:18px}
.pc{background:#fff;border:1px solid var(--line);border-radius:var(--r-lg);overflow:hidden;display:flex;flex-direction:column;transition:transform .5s var(--ease),box-shadow .5s,border-color .3s}
.pc:hover{transform:translateY(-6px);box-shadow:var(--shadow-lift);border-color:transparent}
.pc.hide{display:none}
.pc-stage{position:relative;aspect-ratio:4/5;perspective:1400px;cursor:zoom-in;background:#DCE6EE}
.pc-flip{position:absolute;inset:0;transform-style:preserve-3d;transition:transform .9s var(--ease)}
.pc.back .pc-flip{transform:rotateY(180deg)}
.pc-face{position:absolute;inset:0;backface-visibility:hidden;-webkit-backface-visibility:hidden;overflow:hidden}
.pc-face img{width:100%;height:100%;object-fit:cover;transition:transform 1s var(--ease)}
.pc:hover .pc-face img{transform:scale(1.04)}
.pc-face.b{transform:rotateY(180deg)}
.pc-top{position:absolute;top:14px;inset-inline:14px;z-index:3;display:flex;justify-content:space-between;pointer-events:none}
.pc-no{font-family:var(--f-mono);font-size:.7rem;color:var(--navy);background:rgba(255,255,255,.9);padding:4px 8px;border-radius:4px}
.pc-face-tag{font-size:.68rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#fff;background:rgba(6,26,46,.72);backdrop-filter:blur(6px);padding:4px 9px;border-radius:4px}
.pc-body{padding:18px 18px 18px;display:flex;flex-direction:column;gap:12px;flex:1;border-top:1px solid var(--line)}
.pc-name{display:flex;justify-content:space-between;align-items:baseline;gap:10px}
.pc-name h3{font-family:var(--f-display);font-size:1.12rem;font-weight:700;color:var(--navy-900);letter-spacing:-.015em}
.pc-name span{font-family:var(--f-ar);font-size:.95rem;color:var(--ink-50);font-weight:500}
.pc-meta{display:flex;gap:6px;flex-wrap:wrap}
.pc-meta span{font-size:.72rem;padding:3px 8px;border-radius:4px;background:var(--paper);color:var(--ink-70);border:1px solid var(--line)}
.pc-meta span.s{background:rgba(63,190,35,.1);border-color:rgba(63,190,35,.3);color:var(--green-600)}
.pc-act{display:flex;gap:8px;margin-top:auto}
.pc-act .seg{flex:1}.pc-act .seg button{flex:1;padding:7px 8px}
.add{flex:none;display:inline-flex;align-items:center;gap:6px;padding:0 12px;border-radius:var(--r);border:1px solid var(--navy);color:var(--navy);font-size:.8rem;font-weight:700;transition:all .25s}
.add svg{width:14px;height:14px;transition:transform .3s}
.add:hover{background:var(--navy);color:#fff}
.add.on{background:var(--green-600);border-color:var(--green-600);color:#fff}
.add.on svg{transform:rotate(45deg)}
.pc-cta{background:var(--navy);color:#fff;border-color:var(--navy);padding:30px 26px;justify-content:space-between;position:relative;overflow:hidden}
.pc-cta::before{content:"";position:absolute;inset:0;background:radial-gradient(90% 60% at 100% 0%,rgba(57,185,228,.35),transparent 60%)}
.pc-cta>*{position:relative}
.pc-cta .mono{color:var(--ice-300)}
.pc-cta h3{font-family:var(--f-display);font-size:1.5rem;line-height:1.15;margin:14px 0 12px;letter-spacing:-.02em}
.pc-cta p{font-size:.9rem;color:rgba(255,255,255,.72)}
.pc-cta ul{list-style:none;margin:18px 0 24px;display:grid;gap:9px;font-size:.86rem;color:rgba(255,255,255,.85)}
.pc-cta li{display:flex;gap:10px;align-items:flex-start;line-height:1.45}
.pc-cta li::before{content:"";flex:none;width:12px;height:1px;margin-top:.72em;background:var(--ice)}
.pc-cta .btn{width:100%;justify-content:space-between;white-space:normal;text-align:start;padding:14px 18px;line-height:1.3}
.pc-cta.alt{background:#fff;color:var(--ink);border-color:var(--line)}
.pc-cta.alt::before{background:radial-gradient(90% 60% at 100% 0%,rgba(57,185,228,.14),transparent 60%)}
.pc-cta.alt .mono{color:var(--navy-500)}.pc-cta.alt h3{color:var(--navy-900)}.pc-cta.alt p{color:var(--ink-70)}.pc-cta.alt ul{color:var(--ink-70)}
.p-note{margin-top:28px;font-size:.88rem;color:var(--ink-50);display:flex;gap:10px;align-items:center}
.p-note svg{width:16px;height:16px;color:var(--ice);flex:none}

/* ---------- seasonality (harvest planner) ---------- */
.season{background:var(--paper)}
.planner{display:grid;grid-template-columns:.9fr 1.5fr;gap:clamp(28px,4vw,56px);align-items:start}
.planner .h2{margin-bottom:14px}
.pl-note{margin-top:22px;display:grid;gap:10px;font-size:.84rem;color:var(--ink-70)}
.pl-note span{display:flex;gap:10px;align-items:flex-start}
.pl-note i{flex:none;width:18px;height:18px;border-radius:50%;background:var(--ice-100);color:var(--navy);display:grid;place-items:center;font-style:normal;font-size:.62rem;font-weight:700;margin-top:1px}
.pl-card{background:#fff;border:1px solid var(--line);border-radius:var(--r-lg);overflow:hidden;box-shadow:var(--shadow)}
.months-bar{display:grid;grid-template-columns:repeat(12,1fr);border-bottom:1px solid var(--line)}
.mbtn{position:relative;padding:12px 0 10px;display:flex;flex-direction:column;align-items:center;gap:6px;font-family:var(--f-mono);font-size:.68rem;letter-spacing:.04em;text-transform:uppercase;color:var(--ink-50);border-inline-end:1px solid var(--line);transition:background .25s,color .25s}
html[lang="ar"] .mbtn{font-family:inherit;text-transform:none;font-size:.72rem}
.mbtn:last-child{border-inline-end:0}
.mbtn:hover{background:var(--ice-50);color:var(--navy)}
.mbtn .pips{display:flex;gap:2px;height:5px}
.mbtn .pips i{width:5px;height:5px;border-radius:50%;background:var(--ice)}
.mbtn.now::after{content:"";position:absolute;top:0;inset-inline:0;height:2px;background:var(--green)}
.mbtn.on{background:var(--navy);color:#fff}
.mbtn.on .pips i{background:var(--ice-300)}
.pl-body{padding:22px 24px 24px}
.pl-head{display:flex;justify-content:space-between;align-items:baseline;gap:12px;flex-wrap:wrap;margin-bottom:12px}
.pl-head b{font-family:var(--f-display);font-size:1.15rem;color:var(--navy-900)}
.pl-head span{font-size:.78rem;color:var(--ink-50)}
.crops{display:grid;gap:0}
.crop{display:grid;grid-template-columns:44px 1fr auto;gap:14px;align-items:center;padding:10px 0;border-top:1px solid var(--line);animation:fadeUp .5s var(--ease) both}
.crop img{width:44px;height:55px;object-fit:cover;border-radius:4px;background:#dce6ee}
.crop .ph{width:44px;height:55px;border-radius:4px;background:var(--ice-50);display:grid;place-items:center;color:var(--ice);font-size:.7rem;font-weight:700}
.crop b{font-family:var(--f-display);font-size:.96rem;color:var(--navy-900);display:block}
.crop small{font-size:.76rem;color:var(--ink-50)}
.mini{display:grid;grid-template-columns:repeat(12,7px);gap:2px}
.mini i{height:7px;border-radius:2px;background:var(--line)}
.mini i.on{background:var(--navy)}
.mini i.sel{outline:1.5px solid var(--green);outline-offset:1px}
.pl-empty{padding:14px 0;font-size:.9rem;color:var(--ink-70);border-top:1px solid var(--line)}
.pl-next{margin-top:14px;padding-top:14px;border-top:1px dashed var(--line);font-size:.82rem;color:var(--ink-70);display:flex;gap:8px;flex-wrap:wrap;align-items:center}
.pl-next .mono{color:var(--navy-500)}
.pl-next em{font-style:normal;padding:3px 8px;border-radius:4px;background:var(--paper);border:1px solid var(--line)}
.pl-foot{padding:12px 24px;background:var(--paper);border-top:1px solid var(--line);font-size:.78rem;color:var(--ink-50)}

/* ---------- capabilities ---------- */
.caps{display:grid;grid-template-columns:repeat(4,1fr);border:1px solid var(--line);border-radius:var(--r-lg);overflow:hidden}
.cap{padding:34px 30px 36px;border-inline-end:1px solid var(--line);display:flex;flex-direction:column;gap:14px;position:relative;transition:background .4s}
.cap:last-child{border-inline-end:0}
.cap::before{content:"";position:absolute;top:0;inset-inline:0;height:2px;background:var(--ice);transform:scaleX(0);transform-origin:left;transition:transform .5s var(--ease)}
.cap:hover{background:var(--ice-50)}.cap:hover::before{transform:scaleX(1)}
.cap .ico{width:48px;height:48px;border-radius:var(--r);background:var(--navy);color:var(--ice-300);display:grid;place-items:center}
.cap .ico svg{width:24px;height:24px}
.cap h3{font-family:var(--f-display);font-size:1.25rem;color:var(--navy-900);letter-spacing:-.02em;margin-top:10px}
.cap p{font-size:.92rem;color:var(--ink-70)}
.cap .spec{margin-top:auto;padding-top:16px;border-top:1px dashed var(--line);font-family:var(--f-mono);font-size:.74rem;color:var(--navy-500);letter-spacing:.02em}

/* ---------- logistics ---------- */
.logi{background:var(--navy-900)}
.logi-grid{display:grid;grid-template-columns:1fr 1fr;gap:22px}
.panel{border:1px solid var(--line-dark);border-radius:var(--r-lg);background:rgba(255,255,255,.03);padding:30px}
.panel h3{font-family:var(--f-display);font-size:1.2rem;display:flex;justify-content:space-between;align-items:baseline;gap:12px}
.panel h3 .mono{color:var(--ice-300);font-weight:400}
.spec-table{width:100%;border-collapse:collapse;margin-top:18px}
.spec-table tr{border-top:1px solid var(--line-dark)}
.spec-table td{padding:14px 0;font-size:.92rem;vertical-align:middle}
.spec-table td:first-child{font-family:var(--f-display);font-weight:700;font-size:1.05rem;width:40%;color:#fff}
.spec-table td:last-child{color:rgba(255,255,255,.62);text-align:end}
.spec-table .tagc{display:inline-block;font-size:.7rem;padding:3px 8px;border-radius:4px;background:rgba(57,185,228,.14);color:var(--ice-300);margin-inline-start:8px;font-family:var(--f-mono)}
.containers{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:20px}
.ctn{border:1px solid var(--line-dark);border-radius:var(--r);padding:18px;display:flex;flex-direction:column;gap:12px}
.ctn svg{height:40px;width:auto;color:var(--ice-300)}
.ctn.dry svg{color:rgba(255,255,255,.5)}
.ctn b{font-family:var(--f-display);font-size:1rem}
.ctn .v{font-family:var(--f-display);font-size:1.5rem;font-weight:700;letter-spacing:-.02em;color:#fff;line-height:1}
.ctn .v small{display:block;margin-top:6px;font-family:var(--f-body);font-size:.78rem;font-weight:400;color:rgba(255,255,255,.55);letter-spacing:0}
.ctn p{font-size:.78rem;color:rgba(255,255,255,.55)}
.incoterms{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-top:22px;padding-top:22px;border-top:1px solid var(--line-dark);font-size:.86rem;color:rgba(255,255,255,.66)}
.incoterms b{font-family:var(--f-mono);font-weight:500;font-size:.78rem;padding:6px 11px;border:1px solid rgba(255,255,255,.2);border-radius:4px;color:#fff}
.incoterms b.main{border-color:var(--ice);color:var(--ice)}

/* ---------- markets ---------- */
.markets{background:#fff}
.mk-panel{background:var(--navy-950);color:#fff;border-radius:14px;overflow:hidden;display:grid;grid-template-columns:minmax(300px,.8fr) 1.7fr;position:relative}
.mk-side{padding:clamp(26px,3vw,40px);display:flex;flex-direction:column;gap:16px;border-inline-end:1px solid var(--line-dark)}
.mk-side .h2{color:#fff;font-size:clamp(1.55rem,2.2vw,2.05rem)}
.mk-side .lead{color:rgba(255,255,255,.66);font-size:.93rem}
.mk-stats{display:grid;grid-template-columns:repeat(3,1fr);border-block:1px solid var(--line-dark)}
.mk-stats div{padding:14px 0;text-align:center;border-inline-end:1px solid var(--line-dark)}
.mk-stats div:last-child{border-inline-end:0}
.mk-stats b{display:block;font-family:var(--f-display);font-size:1.35rem;line-height:1}
.mk-stats span{font-size:.7rem;color:rgba(255,255,255,.55)}
.rg-list{display:flex;flex-wrap:wrap;gap:6px}
.rg{display:inline-flex;gap:8px;align-items:center;padding:7px 12px;border:1px solid var(--line-dark);border-radius:40px;font-size:.8rem;color:rgba(255,255,255,.75);transition:background .25s,color .25s;text-align:start}
.rg small{font-family:var(--f-mono);font-size:.7rem;color:rgba(255,255,255,.45)}
.rg:hover{background:rgba(255,255,255,.05);color:#fff}
.rg.on{background:var(--ice);border-color:var(--ice);color:var(--navy-900)}.rg.on small{color:var(--navy)!important}
.rg.on small{color:var(--ice)}
.rg-countries{font-size:.8rem;color:rgba(255,255,255,.6);line-height:1.6;min-height:3.2em}
.map-box{position:relative;padding:clamp(14px,2vw,28px) clamp(10px,1.5vw,20px);display:flex;align-items:center;background:radial-gradient(60% 70% at 55% 40%,rgba(57,185,228,.08),transparent 70%)}
.map-box svg{width:112%;margin-inline:-6%;height:auto;display:block;overflow:visible}
.dots-land{stroke:rgba(143,214,240,.2)}
.dots-mk{stroke:rgba(57,185,228,.8)}
.arc{fill:none;stroke:url(#arcg);stroke-width:.32;stroke-linecap:round;stroke-dasharray:1 1;stroke-dashoffset:1;transition:opacity .4s}
.map-box.in .arc{animation:draw 2.4s var(--ease) forwards}
@keyframes draw{to{stroke-dashoffset:0}}
.hub{fill:#fff;opacity:0;transition:opacity .6s,r .3s}
.map-box.in .hub{opacity:1}
.map-box.filter .arc:not(.hl),.map-box.filter .hub:not(.hl){opacity:.12!important}
.map-box.filter .hub.hl{fill:var(--green)}
.origin-ring{fill:none;stroke:var(--green);stroke-width:.25;transform-box:fill-box;transform-origin:center;animation:ring 2.6s ease-out infinite}
@keyframes ring{from{transform:scale(.4);opacity:1}to{transform:scale(3.2);opacity:0}}
.map-label{position:absolute;transform:translate(-50%,-150%);background:#fff;color:var(--navy);font-size:.7rem;font-weight:700;padding:5px 9px;border-radius:4px;white-space:nowrap;box-shadow:0 10px 30px -10px rgba(0,0,0,.5);pointer-events:none}
.map-label::after{content:"";position:absolute;left:50%;bottom:-4px;width:8px;height:8px;background:#fff;transform:translateX(-50%) rotate(45deg)}

/* ---------- quality ---------- */
.quality{background:var(--paper)}
.cert-rail{display:grid;grid-template-columns:repeat(6,1fr);background:#fff;border:1px solid var(--line);border-radius:var(--r-lg);overflow:hidden}
.cert{padding:22px 18px 20px;display:flex;flex-direction:column;align-items:center;text-align:center;gap:10px;border-inline-end:1px solid var(--line);position:relative;transition:background .3s}
.cert:last-child{border-inline-end:0}
.cert::after{content:"";position:absolute;bottom:0;inset-inline:0;height:2px;background:var(--ice);transform:scaleX(0);transition:transform .45s var(--ease)}
.cert:hover{background:var(--ice-50)}.cert:hover::after{transform:scaleX(1)}
.cert img{height:52px;width:auto;max-width:80%;object-fit:contain;mix-blend-mode:multiply;transition:transform .45s var(--ease)}
.cert:hover img{transform:scale(1.06)}
.cert b{font-family:var(--f-display);font-size:.92rem;color:var(--navy-900)}
.cert span{font-size:.74rem;color:var(--ink-50);line-height:1.4}
.q-bottom{display:grid;grid-template-columns:1.7fr 1fr;gap:18px;margin-top:18px}
.q-flow{display:grid;grid-template-columns:repeat(4,1fr);background:#fff;border:1px solid var(--line);border-radius:var(--r-lg);overflow:hidden}
.q-step{padding:22px 20px;border-inline-end:1px solid var(--line);position:relative}
.q-step:last-child{border-inline-end:0}
.q-step .n{font-family:var(--f-mono);font-size:.7rem;color:var(--ice);display:flex;align-items:center;gap:8px;margin-bottom:12px}
.q-step .n::after{content:"";flex:1;height:1px;background:var(--line)}
.q-step b{font-family:var(--f-display);font-size:.98rem;color:var(--navy-900);display:block;margin-bottom:4px}
.q-step p{font-size:.8rem;color:var(--ink-70);line-height:1.5}
.q-quote{padding:24px 26px;border-radius:var(--r-lg);background:var(--navy);color:#fff;display:flex;flex-direction:column;justify-content:space-between;gap:16px;position:relative;overflow:hidden}
.q-quote::before{content:"";position:absolute;inset:0;background:radial-gradient(80% 70% at 100% 0%,rgba(57,185,228,.3),transparent 60%)}
.q-quote>*{position:relative}
.q-quote svg{width:24px;height:24px;color:var(--ice)}
.q-quote p{font-family:var(--f-display);font-size:1.02rem;font-weight:600;line-height:1.45}
.q-quote span{font-size:.76rem;color:rgba(255,255,255,.6)}

/* ---------- RFQ ---------- */
.rfq{background:var(--paper);padding-top:0}
.rfq-shell{display:grid;grid-template-columns:.9fr 1.3fr;border-radius:var(--r-lg);overflow:hidden;box-shadow:var(--shadow-lift);background:#fff}
.rfq-side{background:var(--navy-900);color:#fff;padding:clamp(28px,3.4vw,44px);display:flex;flex-direction:column;gap:22px;position:relative;overflow:hidden}
.rfq-side::before{content:"";position:absolute;inset:0;background:var(--img-rfq,url(<?php echo $frosty_assets; ?>img/factory/facility-aerial.webp)) center/cover;opacity:.12}
.rfq-side>*{position:relative}
.rfq-side .h2{color:#fff;font-size:clamp(1.8rem,2.6vw,2.4rem)}
.flow{display:grid;gap:0;counter-reset:f}
.flow li{list-style:none;display:grid;grid-template-columns:30px 1fr;gap:10px;padding:10px 0;border-top:1px solid var(--line-dark);position:relative}
.flow .n{font-family:var(--f-mono);font-size:.74rem;color:var(--ice);padding-top:2px}
.flow b{font-family:var(--f-display);font-size:.98rem}
.flow p{display:none}
.flow li{align-items:center}
.direct{display:grid;grid-template-columns:1fr;gap:8px;margin-top:auto}
.direct a{display:flex;align-items:center;gap:12px;padding:11px 14px;font-size:.88rem;border:1px solid var(--line-dark);border-radius:var(--r);font-weight:600;font-size:.92rem;transition:background .25s,border-color .25s}
.direct a:hover{background:rgba(255,255,255,.06);border-color:rgba(255,255,255,.3)}
.direct svg{width:18px;height:18px;color:var(--ice);flex:none}
.rfq-form{padding:clamp(28px,4vw,52px);display:grid;gap:18px}
.rfq-form .form-head{display:flex;justify-content:space-between;align-items:baseline;gap:14px;flex-wrap:wrap;padding-bottom:18px;border-bottom:1px solid var(--line)}
.rfq-form .form-head b{font-family:var(--f-display);font-size:1.3rem;color:var(--navy-900)}
.rfq-form .form-head span{font-size:.82rem;color:var(--ink-50)}
.stepper{display:grid;grid-template-columns:1fr 1fr;gap:10px;list-style:none}
.stepper li{position:relative;overflow:hidden;display:flex;align-items:center;gap:10px;padding:11px 14px;border-radius:var(--r);border:1px solid var(--line);font-size:.84rem;font-weight:600;color:var(--ink-50);cursor:pointer;transition:border-color .3s,color .3s}
.stepper li i{font-style:normal;flex:none;width:24px;height:24px;border-radius:50%;display:grid;place-items:center;background:var(--paper);font-family:var(--f-mono);font-size:.72rem;transition:background .3s,color .3s}
.stepper li::after{content:"";position:absolute;bottom:0;inset-inline-start:0;height:2px;width:100%;background:var(--ice);transform:scaleX(0);transform-origin:left;transition:transform .5s var(--ease)}
html[dir="rtl"] .stepper li::after{transform-origin:right}
.stepper li.on{border-color:var(--navy);color:var(--navy-900)}.stepper li.on::after{transform:scaleX(1)}
.stepper li.on i{background:var(--navy);color:#fff}
.stepper li.done{color:var(--navy-900)}.stepper li.done i{background:var(--green-600);color:#fff;font-size:0}.stepper li.done i::before{content:"✓";font-size:.78rem}
.fstep{display:none;gap:18px}.fstep.on{display:grid;animation:fadeUp .45s var(--ease)}
.step-nav{display:flex;align-items:center;gap:16px;flex-wrap:wrap;padding-top:8px}.step-nav .btn{border:0}.step-nav p{font-size:.8rem;color:var(--ink-50)}
.rfq-form{display:flex;flex-direction:column}
.fstep.on{display:flex;flex-direction:column;flex:1}
.fstep .step-nav{margin-top:auto;padding-top:22px}
.row2{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.fld{display:grid;gap:7px}
.fld label{font-size:.78rem;font-weight:600;color:var(--ink-70);letter-spacing:.01em}
.fld input,.fld select,.fld textarea{width:100%;padding:13px 14px;border:1px solid var(--line);border-radius:var(--r);background:var(--paper);font-size:.93rem;transition:border-color .2s,background .2s,box-shadow .2s;appearance:none}
.fld select{background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%236B7C8E' stroke-width='2'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E");background-repeat:no-repeat;background-size:16px;background-position:right 12px center;padding-inline-end:36px}
html[dir="rtl"] .fld select{background-position:left 12px center}
.fld textarea{min-height:100px;resize:vertical}
.fld :is(input,select,textarea):focus{outline:0;border-color:var(--ice);background:#fff;box-shadow:0 0 0 4px rgba(57,185,228,.14)}
.fld.err :is(input,select){border-color:#D64545;background:#FFF6F6}
.chips{display:flex;flex-wrap:wrap;gap:7px}
.chip{padding:8px 13px;border-radius:40px;border:1px solid var(--line);font-size:.82rem;font-weight:500;color:var(--ink-70);background:#fff;transition:all .2s;user-select:none;cursor:pointer}
.chip:hover{border-color:var(--navy-500)}
.chip.on{background:var(--navy);border-color:var(--navy);color:#fff}
.chip.on::before{content:"✓ ";color:var(--ice-300)}
.chips.err .chip{border-color:#E7A0A0}
.submit{display:flex;align-items:center;gap:18px;flex-wrap:wrap;padding-top:6px}
.submit .btn{border:0}
.submit p{font-size:.8rem;color:var(--ink-50);max-width:38ch}
.toast{display:none;padding:13px 16px;border-radius:var(--r);font-size:.88rem;font-weight:500}
.toast.show{display:block}.toast.ok{background:rgba(63,190,35,.1);color:var(--green-600);border:1px solid rgba(63,190,35,.3)}.toast.bad{background:#FFF1F1;color:#B83232;border:1px solid #F2C4C4}

/* ---------- FAQ (master–detail) ---------- */
.faq-shell{display:grid;grid-template-columns:1fr 1fr;gap:clamp(24px,3.5vw,48px);align-items:stretch}
.fq-list{border-top:1px solid var(--line);align-self:start}
.fq{border-bottom:1px solid var(--line)}
.fq-q{width:100%;display:grid;grid-template-columns:34px 1fr 20px;gap:10px;align-items:center;padding:15px 12px 15px 0;text-align:start;font-family:var(--f-display);font-weight:600;font-size:.96rem;color:var(--ink-70);position:relative;transition:color .25s}
.fq-q .n{font-family:var(--f-mono);font-size:.7rem;color:var(--ink-50);font-weight:400}
.fq-q svg{width:16px;height:16px;opacity:0;transform:translateX(-6px);transition:opacity .3s,transform .3s var(--ease);color:var(--ice)}
html[dir="rtl"] .fq-q svg{transform:scaleX(-1) translateX(-6px)}
.fq-q::before{content:"";position:absolute;inset-inline-start:-14px;top:50%;width:3px;height:0;background:var(--ice);transform:translateY(-50%);transition:height .35s var(--ease)}
.fq-q:hover{color:var(--navy)}
.fq.on .fq-q{color:var(--navy-900)}
.fq.on .fq-q .n{color:var(--ice)}
.fq.on .fq-q::before{height:60%}
.fq.on .fq-q svg{opacity:1;transform:none}
html[dir="rtl"] .fq.on .fq-q svg{transform:scaleX(-1)}
.fq-a{display:none;padding:0 0 18px 44px;font-size:.92rem;color:var(--ink-70)}
html[dir="rtl"] .fq-a{padding:0 44px 18px 0}
.faq-panel{position:relative;background:var(--navy-900);color:#fff;border-radius:var(--r-lg);padding:clamp(26px,3vw,40px);min-height:360px;display:flex;flex-direction:column;overflow:hidden}
.faq-panel::before{content:"";position:absolute;inset:0;background:radial-gradient(70% 60% at 100% 0%,rgba(57,185,228,.22),transparent 60%);pointer-events:none}
.faq-panel>*{position:relative}
.fp-count{font-family:var(--f-mono);font-size:.72rem;color:var(--ice-300);letter-spacing:.08em}
.fp-q{font-family:var(--f-display);font-size:clamp(1.25rem,1.8vw,1.55rem);line-height:1.25;letter-spacing:-.02em;margin:14px 0 14px}
.fp-a{font-size:.95rem;color:rgba(255,255,255,.74);line-height:1.7}
.fp-swap{animation:fadeUp .45s var(--ease)}
.fp-foot{margin-top:auto;padding-top:22px;border-top:1px solid var(--line-dark);display:flex;justify-content:space-between;align-items:center;gap:14px;flex-wrap:wrap;font-size:.84rem;color:rgba(255,255,255,.6)}
.fp-foot a{color:#fff;font-weight:600;display:inline-flex;gap:8px;align-items:center}
.fp-foot a svg{width:16px;height:16px;color:var(--ice)}
.consumer{margin-top:28px;padding:14px 16px;border-radius:var(--r);background:var(--ice-50);border:1px solid var(--ice-100);display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;font-size:.84rem;color:var(--ink-70)}
.consumer b{color:var(--navy-900);font-weight:600}
.consumer .links{display:flex;gap:14px;font-weight:600;color:var(--navy)}
.consumer .links a{text-decoration:underline;text-underline-offset:3px}

/* ---------- contact ---------- */
.contact{background:var(--paper);padding-top:0}
.offices{display:grid;grid-template-columns:1fr 1fr 1fr;gap:18px}
.office{background:#fff;border:1px solid var(--line);border-radius:var(--r-lg);padding:30px;display:flex;flex-direction:column;gap:10px}
.office .mono{color:var(--navy-500)}
.office h3{font-family:var(--f-display);font-size:1.3rem;color:var(--navy-900)}
.office p{font-size:.92rem;color:var(--ink-70)}
.office a.lnk{margin-top:auto;padding-top:16px;display:inline-flex;align-items:center;gap:8px;font-weight:600;font-size:.88rem;color:var(--navy)}
.office a.lnk svg{width:16px;height:16px}
.office.big{background:var(--navy);color:#fff;border-color:var(--navy)}
.office.big .mono{color:var(--ice-300)}.office.big h3{color:#fff}.office.big p{color:rgba(255,255,255,.7)}
.office.big a.v{font-family:var(--f-display);font-size:1.02rem;overflow-wrap:anywhere;font-weight:700;display:flex;align-items:center;gap:10px}
.office.big a.v svg{width:18px;height:18px;color:var(--ice)}
.cta-band{margin-top:clamp(70px,8vw,110px);position:relative;border-radius:var(--r-lg);overflow:hidden;background:var(--navy-900);color:#fff;display:grid;grid-template-columns:1.2fr 1fr;align-items:center;min-height:360px}
.cta-band .txt{padding:clamp(32px,5vw,64px);position:relative;z-index:2}
.cta-band .h2{color:#fff}
.cta-band p{color:rgba(255,255,255,.72);margin:18px 0 30px;max-width:48ch}
.cta-band .btns{display:flex;gap:12px;flex-wrap:wrap}
.cta-packs{position:relative;height:100%;min-height:360px}
.cta-packs img{position:absolute;width:44%;border-radius:8px;box-shadow:0 30px 60px -20px rgba(0,0,0,.6);transition:transform 1.2s var(--ease)}
.cta-packs img:nth-child(1){left:6%;top:14%;transform:rotate(-8deg)}
.cta-packs img:nth-child(2){left:30%;top:6%;z-index:2}
.cta-packs img:nth-child(3){left:54%;top:14%;transform:rotate(8deg)}
.cta-band:hover .cta-packs img:nth-child(1){transform:rotate(-11deg) translateX(-10px)}
.cta-band:hover .cta-packs img:nth-child(3){transform:rotate(11deg) translateX(10px)}
.cta-band:hover .cta-packs img:nth-child(2){transform:translateY(-8px)}

/* ---------- footer ---------- */
.footer{background:var(--navy-950);color:rgba(255,255,255,.66);padding:80px 0 30px;font-size:.9rem}
.f-grid{display:grid;grid-template-columns:1.4fr 1fr 1fr 1fr;gap:40px}
.f-brand img{height:56px;width:auto;margin-bottom:18px}
.f-brand p{max-width:36ch}
.footer h5{font-family:var(--f-mono);font-weight:500;font-size:.72rem;letter-spacing:.1em;text-transform:uppercase;color:var(--ice-300);margin-bottom:16px}
html[lang="ar"] .footer h5{font-family:inherit;letter-spacing:0;font-size:.85rem}
.footer ul{list-style:none;display:grid;gap:9px}
.footer a:hover{color:#fff}
.socials{display:flex;gap:10px;margin-top:22px}
.socials a{width:40px;height:40px;border-radius:50%;border:1px solid var(--line-dark);display:grid;place-items:center;transition:all .25s}
.socials a:hover{background:var(--ice);color:var(--navy-900);border-color:var(--ice)}
.socials svg{width:17px;height:17px}
.f-certs{display:flex;gap:8px;margin-top:20px;flex-wrap:wrap}
.f-certs img{width:40px;height:40px;object-fit:contain;background:#fff;border-radius:4px;padding:3px}
.f-bottom{margin-top:60px;padding-top:24px;border-top:1px solid var(--line-dark);display:flex;justify-content:space-between;gap:20px;flex-wrap:wrap;font-size:.8rem;color:rgba(255,255,255,.45)}

/* ---------- modal (spec sheet) ---------- */
.modal-bg{position:fixed;inset:0;z-index:100;background:rgba(4,18,33,.7);backdrop-filter:blur(8px);display:grid;place-items:center;padding:24px;opacity:0;pointer-events:none;transition:opacity .35s}
.modal-bg.open{opacity:1;pointer-events:auto}
.modal{background:#fff;border-radius:var(--r-lg);width:min(1120px,100%);max-height:calc(100svh - 48px);overflow:auto;display:grid;grid-template-columns:1.05fr 1fr;transform:translateY(20px) scale(.98);transition:transform .45s var(--ease);position:relative}
.modal-bg.open .modal{transform:none}
.m-close{position:absolute;top:14px;inset-inline-end:14px;z-index:5;width:42px;height:42px;border-radius:50%;background:#fff;border:1px solid var(--line);display:grid;place-items:center;transition:transform .3s,background .3s}
.m-close:hover{transform:rotate(90deg);background:var(--paper)}
.m-close svg{width:16px;height:16px}
.m-media{background:#DCE6EE;padding:22px;display:flex;flex-direction:column;justify-content:center;gap:14px}
.m-views{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.m-view{border-radius:var(--r);overflow:hidden;position:relative;cursor:zoom-in;background:#cfdbe5}
.m-view img{width:100%;aspect-ratio:4/5;object-fit:cover}
.m-view span{position:absolute;bottom:10px;inset-inline-start:10px;font-size:.66rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;background:rgba(6,26,46,.75);color:#fff;padding:4px 9px;border-radius:4px}
.m-media p{font-size:.78rem;color:var(--ink-70);text-align:center}
.m-body{padding:clamp(26px,3vw,42px);display:flex;flex-direction:column;gap:18px}
.m-body .mono{color:var(--navy-500)}
.m-title{display:flex;align-items:baseline;gap:14px;flex-wrap:wrap}
.m-title h3{font-family:var(--f-display);font-size:2rem;color:var(--navy-900);letter-spacing:-.03em;line-height:1.1}
.m-title span{font-family:var(--f-ar);font-size:1.2rem;color:var(--ink-50)}
.m-desc{color:var(--ink-70);font-size:.95rem}
.sheet{width:100%;border-collapse:collapse;font-size:.88rem}
.sheet tr{border-top:1px solid var(--line)}
.sheet tr:last-child{border-bottom:1px solid var(--line)}
.sheet th{width:34%;text-align:start;padding:12px 12px 12px 0;font-weight:600;color:var(--ink-50);font-size:.78rem;vertical-align:top}
.sheet td{padding:10px 0;color:var(--navy-900);font-weight:500}
.tag{display:inline-block;font-size:.76rem;padding:3px 9px;border-radius:4px;background:var(--paper);border:1px solid var(--line);margin:2px 4px 2px 0;font-weight:500}
.months{display:grid;grid-template-columns:repeat(12,1fr);gap:3px}
.months i{font-style:normal;font-size:.62rem;text-align:center;padding:5px 0;border-radius:3px;background:var(--paper);color:var(--ink-50);font-family:var(--f-mono)}
.months i.on{background:var(--navy);color:#fff}
.m-ctas{display:flex;gap:10px;flex-wrap:wrap;margin-top:auto}
.m-ctas .btn{border:0}
.lightbox{position:fixed;inset:0;z-index:120;background:rgba(4,18,33,.94);display:grid;place-items:center;padding:30px;opacity:0;pointer-events:none;transition:opacity .3s;cursor:zoom-out}
.lightbox.open{opacity:1;pointer-events:auto}
.lightbox img{max-height:92svh;width:auto;border-radius:8px}

/* ---------- responsive ---------- */
@media (max-width:1180px){
  .trust .wrap{grid-template-columns:1fr;gap:16px}.marquee{border-inline-start:0}
  .util .hide-m{display:none}
  .nav-links{gap:22px}.nav-links a{font-size:.85rem}
  .p-grid{grid-template-columns:repeat(3,1fr)}
  .caps{grid-template-columns:1fr 1fr}.cap:nth-child(2){border-inline-end:0}.cap:nth-child(-n+2){border-bottom:1px solid var(--line)}
}
@media (max-width:980px){
  .planner,.mk-panel,.faq-shell,.q-bottom{grid-template-columns:1fr}
  .mk-side{border-inline-end:0;border-bottom:1px solid var(--line-dark)}
  .cert-rail{grid-template-columns:repeat(3,1fr)}.cert:nth-child(3){border-inline-end:0}.cert:nth-child(-n+3){border-bottom:1px solid var(--line)}
  .faq-panel{display:none}
  .fq.on .fq-a{display:block;animation:fadeUp .4s var(--ease)}
  .fq-q svg{opacity:1;transform:rotate(90deg)}.fq.on .fq-q svg{transform:rotate(-90deg)}
  html[dir="rtl"] .fq-q svg{transform:rotate(90deg)}html[dir="rtl"] .fq.on .fq-q svg{transform:rotate(-90deg)}
  .nav-links,.util-l .hide-m{display:none}
  .burger{display:flex}
  .nav .wrap{gap:14px}.nav-cta{margin-inline-start:auto}
  .sec-head,.company-grid,.rfq-shell,.logi-grid,.cta-band{grid-template-columns:1fr}
  .sec-head{gap:18px}
  .facts{grid-template-columns:1fr 1fr}.fact:nth-child(2){border-inline-end:0}.fact:nth-child(-n+2){border-bottom:1px solid var(--line)}
  .iqf-row{grid-template-columns:1fr}
  .process{grid-template-columns:repeat(3,1fr);row-gap:40px}.process-line{display:none}
  .offices{grid-template-columns:1fr}
  .f-grid{grid-template-columns:1fr 1fr}
  .modal{grid-template-columns:1fr}
  .cta-packs{min-height:300px;margin-bottom:30px}
  .trust .wrap{grid-template-columns:1fr;gap:18px}.marquee{border-inline-start:0}
}
@media (max-width:720px){
  .logi-grid>*,.p-tools>*,.containers>*{min-width:0}
  .panel{padding:20px}.spec-table td:first-child{width:auto;font-size:.95rem}.spec-table .tagc{display:none}
  .ctn .v{font-size:1.2rem}
  .trust-certs{flex-wrap:wrap;gap:8px}.trust-certs img{width:54px;height:54px;padding:4px}.trust-label{flex-basis:100%;max-width:none;margin:0 0 4px}
  .face-switch{flex-wrap:wrap}
  .values{grid-template-columns:1fr}.value:nth-child(odd){border-inline-end:0}.value:nth-child(even){padding-inline-start:0}
  .facility{min-height:320px}
  .pc-cta{grid-column:1/-1;padding:24px 20px}.pc-cta .btn{width:auto;align-self:flex-start}
  .figs{grid-template-columns:1fr 1fr}.fig:nth-child(2){border-inline-end:0}.fig:nth-child(-n+2){border-bottom:1px solid rgba(255,255,255,.08)}
  .months-bar{grid-template-columns:repeat(6,1fr)}.mbtn:nth-child(6){border-inline-end:0}.mbtn:nth-child(-n+6){border-bottom:1px solid var(--line)}
  .pl-body{padding:18px 16px}.crop{grid-template-columns:40px 1fr}.crop .mini{grid-column:2;grid-template-columns:repeat(12,6px)}
  .q-flow{grid-template-columns:1fr 1fr}.q-step:nth-child(2){border-inline-end:0}.q-step:nth-child(-n+2){border-bottom:1px solid var(--line)}
  .cert-rail{grid-template-columns:1fr 1fr}.cert:nth-child(3){border-inline-end:1px solid var(--line)}.cert:nth-child(2n){border-inline-end:0}.cert:nth-child(-n+4){border-bottom:1px solid var(--line)}
  :root{--gut:20px}
  body{font-size:15px}
  .util .wrap{justify-content:space-between}.util-l{display:none}
  .nav-cta span.t{display:none}.nav-cta{padding:12px 14px}
  .nav-logo img{height:40px}
  .hero{min-height:720px}
  .p-grid{grid-template-columns:1fr 1fr;gap:10px}
  .pc-body{padding:12px;gap:9px}
  .pc-name{flex-direction:column;gap:0}.pc-name h3{font-size:.98rem}.pc-name span{font-size:.85rem}
  .pc-act{flex-direction:column}.add{justify-content:center;padding:8px}
  .pc-meta span:nth-child(n+2){display:none}
  .pc-face-tag{display:none}
  .pc-no{font-size:.62rem;padding:3px 6px}
  .p-tools{flex-direction:column;align-items:stretch;flex-wrap:nowrap}.tabs{overflow-x:auto;flex-wrap:nowrap}.tab{flex:none}
  .caps{grid-template-columns:1fr}.cap{border-inline-end:0;border-bottom:1px solid var(--line)}
  .process{grid-template-columns:1fr 1fr}
  .iqf-card{grid-template-columns:96px 1fr;padding:20px;gap:16px}
  .containers,.row2{grid-template-columns:1fr 1fr}
  .row2{grid-template-columns:1fr}
  .f-grid{grid-template-columns:1fr}
  .facts{grid-template-columns:1fr}.fact{border-inline-end:0;border-bottom:1px solid var(--line)}
  .map-label{display:none}
  .m-views{grid-template-columns:1fr 1fr}
  .cta-packs img{width:46%}
}
@media (prefers-reduced-motion:reduce){
  *,*::before,*::after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}
  .rv{opacity:1;transform:none}.hero .h1 .ln>span{transform:none}.fade-up{opacity:1}
}
</style>
<?php wp_head(); ?>
</head>
<body>
<?php if ( function_exists( 'wp_body_open' ) ) { wp_body_open(); } ?>

<!-- ============ UTILITY BAR ============ -->
<div class="util">
  <div class="wrap">
    <div class="util-l">
      <span data-k="t1" class="util-tag" data-ar="مكتب التصدير">Export Desk</span>
      <a data-lk="l1" href="mailto:export@frosty-foods.com"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/></svg><span data-k="t2" data-ar="export@frosty-foods.com">export@frosty-foods.com</span></a>
      <a data-lk="l2" href="tel:+2034854400" dir="ltr"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg><span data-k="t3" data-ar="+2 034854400">+2 034854400</span></a>
      <span data-k="t4" class="hide-m" data-ar="الإسكندرية، مصر · التصدير إلى أكثر من 50 دولة">Alexandria, Egypt · Exporting to 50+ countries</span>
    </div>
    <div class="util-r">
      <a data-k="t5" data-ar="Facebook" data-lk="l3" href="https://www.facebook.com/frostyfoodseg" target="_blank" rel="noopener">Facebook</a>
      <a data-k="t6" data-ar="Instagram" data-lk="l4" href="https://www.instagram.com/frostyfoods.eg/" target="_blank" rel="noopener">Instagram</a>
      <div class="lang" role="group" aria-label="Language"><button id="lEn" class="on">EN</button><button id="lAr">عربي</button></div>
    </div>
  </div>
</div>

<!-- ============ NAV ============ -->
<header class="nav" id="nav">
  <div class="wrap">
    <a href="#top" class="nav-logo" aria-label="Frosty Foods"><img data-ik="i1" src="<?php echo $frosty_assets; ?>img/logo.png" alt="Frosty Foods"></a>
    <nav class="nav-links" aria-label="Main">
      <a data-k="t7" href="#company" data-ar="الشركة">Company</a>
      <a data-k="t8" href="#production" data-ar="الإنتاج">Production</a>
      <a data-k="t9" href="#products" data-ar="المنتجات">Products</a>
      <a data-k="t10" href="#capabilities" data-ar="حلول الأعمال">Solutions</a>
      <a data-k="t11" href="#markets" data-ar="الأسواق">Markets</a>
      <a data-k="t12" href="#quality" data-ar="الجودة">Quality</a>
      <a data-k="t13" href="#contact" data-ar="تواصل">Contact</a>
    </nav>
    <a href="#rfq" class="btn btn-primary nav-cta"><span data-k="t14" class="t" data-ar="اطلب عرض سعر">Request a quote</span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14M13 6l6 6-6 6"/></svg><span class="cnt" id="basketCnt">0</span></a>
    <button class="burger" id="burger" aria-label="Menu" aria-expanded="false"><span></span><span></span><span></span></button>
  </div>
</header>
<div class="mmenu" id="mmenu">
  <a data-k="t15" href="#company" data-ar="الشركة">Company</a>
  <a data-k="t16" href="#production" data-ar="الإنتاج">Production</a>
  <a data-k="t17" href="#products" data-ar="المنتجات">Products</a>
  <a data-k="t18" href="#capabilities" data-ar="حلول الأعمال">Solutions</a>
  <a data-k="t19" href="#markets" data-ar="الأسواق">Markets</a>
  <a data-k="t20" href="#quality" data-ar="الجودة">Quality</a>
  <a data-k="t21" href="#contact" data-ar="تواصل">Contact</a>
  <a data-k="t22" href="#rfq" class="btn btn-primary" data-ar="اطلب عرض سعر">Request a quote</a>
</div>

<!-- ============ HERO (original video) ============ -->
<section class="hero" id="top">
  <div class="hero-media">
    <video data-ik="i2" autoplay muted loop playsinline preload="auto" poster="<?php echo $frosty_assets; ?>img/misc/hero-poster.jpg"><source src="<?php echo $frosty_assets; ?>hero-video.mp4" type="video/mp4"></video>
  </div>
  <div class="hero-body">
    <div class="wrap hero-copy">
      <span class="hero-kicker fade-up"><span class="dot"></span><span data-k="t23" data-ar="مصنّع ومصدّر معتمد · مصر">Certified IQF manufacturer &amp; exporter · Egypt</span></span>
      <h1 class="h1">
        <span class="ln"><span data-k="t24" data-ar="حصاد مصر،">Egypt's harvest,</span></span>
        <span class="ln"><span data-k="t25" data-ar="<em>مجمّد لأسواق العالم.</em>"><em>frozen for the world.</em></span></span>
      </h1>
      <p data-k="t26" class="lead fade-up fu2" data-ar="خضروات وفواكه مجمدة IQF معتمدة — للمستوردين وسلاسل التجزئة وقطاع الضيافة في أكثر من 50 دولة.">Certified IQF fruits and vegetables for importers, retail chains and food service in 50+ countries.</p>
      <div class="hero-ctas fade-up fu3">
        <a href="#rfq" class="btn btn-primary"><span data-k="t27" data-ar="اطلب عرض سعر">Request a quotation</span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
        <a href="#products" class="btn btn-ghost"><span data-k="t28" data-ar="استعرض المنتجات">View the range</span></a>
      </div>
    </div>
  </div>
  <div class="hero-figs fade-up fu4">
    <div class="wrap">
      <div class="figs">
        <div class="fig"><b><span data-nk="n1" class="count" data-to="50">0</span><small>+</small></b><span data-k="t29" data-ar="دولة نصدّر إليها">Export countries</span></div>
        <div class="fig"><b><span data-nk="n2" class="count" data-to="14">0</span></b><span data-k="t30" data-ar="منتجًا مجمدًا">IQF product lines</span></div>
        <div class="fig"><b><span data-nk="n3" class="count" data-to="6">0</span></b><span data-k="t31" data-ar="شهادات دولية">Certifications</span></div>
        <div class="fig"><b dir="ltr"><span data-k="t32" data-ar="−18">−18</span><small data-k="t33" data-ar="°C">°C</small></b><span data-k="t34" data-ar="سلسلة تبريد متصلة">Cold chain</span></div>
      </div>
    </div>
    <div class="season-now"><span class="mono" id="seasonLabel">In season now</span><span id="seasonText"></span></div>
  </div>
</section>

<!-- ============ TRUST STRIP ============ -->
<div class="trust" id="trust">
  <div class="wrap">
    <div class="trust-certs">
      <span data-k="t35" class="trust-label" data-ar="معتمدون وفق أعلى معايير سلامة الغذاء">Certified to global food-safety standards</span>
      <img data-ik="i3" src="<?php echo $frosty_assets; ?>img/certs/cert-0.png" alt="BRC Food"><img data-ik="i4" src="<?php echo $frosty_assets; ?>img/certs/cert-2.png" alt="ISO 22000"><img data-ik="i5" src="<?php echo $frosty_assets; ?>img/certs/cert-3.png" alt="ISO 9001:2015"><img data-ik="i6" src="<?php echo $frosty_assets; ?>img/certs/cert-4.png" alt="FSSC 22000"><img data-ik="i7" src="<?php echo $frosty_assets; ?>img/certs/cert-1.png" alt="FDA"><img data-ik="i8" src="<?php echo $frosty_assets; ?>img/certs/cert-5.png" alt="KLBD Kosher">
    </div>
    <div class="marquee" aria-label="International exhibitions"><div class="mq-track" id="mq"></div></div>
  </div>
</div>

<!-- ============ 01 COMPANY ============ -->
<section class="sec" id="company">
  <div class="wrap">
    <div class="company-grid">
      <div>
        <div class="sh rv"><span data-k="t36" data-ar="01" class="idx">01</span><span class="rule"></span><span data-k="t37" class="mono" data-ar="الشركة">Company</span></div>
        <h2 data-k="t38" class="h2 rv d1" data-ar="من البيوت المصرية إلى <span class='accent'>أكثر من 50 سوقًا</span> حول العالم.">From Egyptian homes to <span class="accent">50+ markets</span> worldwide.</h2>
        <p data-k="t39" class="lead rv d2" style="margin-top:22px" data-ar="«فروستي فودز» شركة متخصصة في المنتجات المجمدة الفاخرة، تغطي كل مراحل الرحلة — من اختيار المحصول والتصنيع إلى التعبئة والتوريد. مهمتنا: منتجات مجمدة عالية الجودة بأسعار عادلة، للتجزئة والجملة حول العالم.">Frosty Foods is a premium frozen-products specialist covering every stage of the chain — crop selection, processing, packing and supply. Our mission: high-quality frozen products at fair prices, for retail and bulk customers all over the world.</p>
        <div class="values">
          <div class="value rv"><span data-k="t40" data-ar="01" class="n">01</span><div><b data-k="t41" data-ar="النمو">Growth</b><p data-k="t42" data-ar="دول جديدة، ومنتجات أكثر، ووصول لكل المناطق.">New countries, a broader range, and reach into every region.</p></div></div>
          <div class="value rv d1"><span data-k="t43" data-ar="02" class="n">02</span><div><b data-k="t44" data-ar="الجودة">Quality</b><p data-k="t45" data-ar="عمليات معتمدة من اختيار البذور حتى العبوة المغلقة.">Certified processes from seed selection to the sealed pack.</p></div></div>
          <div class="value rv d2"><span data-k="t46" data-ar="03" class="n">03</span><div><b data-k="t47" data-ar="رضا العملاء">Satisfaction</b><p data-k="t48" data-ar="سلسلة توريد مصممة لتسليم ثابت وموثوق.">A supply chain designed for consistent, reliable delivery.</p></div></div>
          <div class="value rv d3"><span data-k="t49" data-ar="04" class="n">04</span><div><b data-k="t50" data-ar="الابتكار">Innovation</b><p data-k="t51" data-ar="أحدث تقنيات التجميد الفردي في كل مرحلة.">Current IQF technology across every production step.</p></div></div>
        </div>
      </div>
      <figure class="facility rv d1">
        <img data-ik="i9" src="<?php echo $frosty_assets; ?>img/factory/facility-aerial.webp" alt="Frosty Foods facility" id="facImg" loading="lazy">
        <figcaption><div><b data-k="t52" data-ar="من المزرعة إلى الحاوية">From field to container</b><span data-k="t53" data-ar="تصنيع · تجميد IQF · تخزين مبرد · تصدير">Processing · IQF freezing · Cold storage · Export</span></div></figcaption>
      </figure>
    </div>
    <div class="facts rv">
      <div class="fact"><span data-k="t54" class="mono" data-ar="المقر الرئيسي">Head office</span><b data-k="t55" data-ar="الإسكندرية، مصر">Alexandria, Egypt</b><p data-k="t56" data-ar="66 طريق الحرية، العطارين">66 El Horreya Rd., Al Attareen</p></div>
      <div class="fact"><span data-k="t57" class="mono" data-ar="المصنع">Factory</span><b data-k="t58" data-ar="برج العرب الجديدة">New Borg El Arab</b><p data-k="t59" data-ar="المنطقة الصناعية الرابعة">4th Industrial Zone, Alexandria</p></div>
      <div class="fact"><span data-k="t60" class="mono" data-ar="الأسواق">Markets</span><b data-k="t61" data-ar="أكثر من 50 دولة">50+ countries</b><p data-k="t62" data-ar="أوروبا، الأمريكتان، الخليج، آسيا وأستراليا">Europe, the Americas, GCC, Asia &amp; Australia</p></div>
      <div class="fact"><span data-k="t63" class="mono" data-ar="المعايير">Standards</span><b data-k="t64" data-ar="BRC · ISO · FSSC">BRC · ISO · FSSC</b><p data-k="t65" data-ar="إضافة إلى تسجيل FDA وشهادة كوشر KLBD">Plus FDA registration &amp; KLBD Kosher</p></div>
    </div>
  </div>
</section>

<!-- ============ 02 PRODUCTION ============ -->
<section class="sec dark production" id="production">
  <div class="prod-bg" id="prodBg" aria-hidden="true"></div>
  <div class="wrap">
    <div class="sec-head">
      <div>
        <div class="sh rv"><span data-k="t66" data-ar="02" class="idx">02</span><span class="rule"></span><span data-k="t67" class="mono" data-ar="الإنتاج والتقنية">Production &amp; technology</span></div>
        <h2 data-k="t68" class="h2 rv d1" data-ar="كل قطعة تُجمَّد <span class='accent'>بمفردها.</span>">Every piece, frozen <span class="accent">on its own.</span></h2>
      </div>
      <p data-k="t69" class="lead rv d2" data-ar="التجميد الفردي السريع (IQF) يجمّد كل قطعة على حدة قبل أن تتكون بلورات ثلج كبيرة تتلف جدران الخلايا — فيبقى الطعم والقوام والقيمة الغذائية كما كانت يوم الحصاد، ولن تجد كتلة متجمدة في أي عبوة.">Individual Quick Freezing locks each piece separately — before large ice crystals can damage the cell walls. Taste, texture and nutrition stay as they were on harvest day, and there is never a solid block in the bag.</p>
    </div>
    <div class="iqf-row">
      <div class="iqf-card bad rv"><div class="pieces" id="pBad"></div><div><span data-k="t70" class="mono" data-ar="التجميد التقليدي">Conventional block freezing</span><b data-k="t71" data-ar="كتلة واحدة متجمدة">One solid block</b><p data-k="t72" data-ar="القطع تلتصق ببعضها وتتمزق الخلايا — فيضيع الطعم والقيمة عند التسييح.">Pieces fuse together and crystals rupture cells — flavour and nutrients drain on thawing.</p></div></div>
      <div class="iqf-card good rv d1"><div class="pieces" id="pGood"></div><div><span data-k="t73" class="mono" data-ar="تجميد فروستي IQF">Frosty IQF</span><b data-k="t74" data-ar="قطع منفصلة وحرة">Free-flowing pieces</b><p data-k="t75" data-ar="كل قطعة مجمدة وحدها — يستخدم العميل ما يحتاجه ويحفظ الباقي دون هدر.">Each piece frozen individually — portion exactly what's needed, keep the rest, zero waste.</p></div></div>
    </div>
    <div class="process" id="process">
      <div class="process-line"><i id="processFill"></i></div>
      <div class="pstep"><div class="node"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M12 21V11M12 11c0-4 3-7 7-7 0 4-3 7-7 7zM12 14c0-3-2.5-5.5-6-5.5 0 3 2.5 5.5 6 5.5z"/><path d="M4 21h16"/></svg></div><span data-k="t76" data-ar="01" class="mono">01</span><b data-k="t77" data-ar="الزراعة والاختيار">Farming &amp; selection</b><p data-k="t78" data-ar="أفضل مناطق الزراعة في مصر مع انتقاء دقيق للمحاصيل والبذور.">Egypt's best growing regions, with careful crop &amp; seed selection.</p></div>
      <div class="pstep"><div class="node"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M4 20c6 0 9-3 9-9V4"/><path d="M13 4c3 1 6 4 7 8M9 8c-2 0-4 1-5 3"/></svg></div><span data-k="t79" data-ar="02" class="mono">02</span><b data-k="t80" data-ar="الحصاد">Harvest</b><p data-k="t81" data-ar="يُقطف في ذروة النضج بتقنيات حصاد حديثة.">Picked at peak ripeness with modern harvesting technology.</p></div>
      <div class="pstep"><div class="node"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M3 7h18M6 12h12M10 17h4"/></svg></div><span data-k="t82" data-ar="03" class="mono">03</span><b data-k="t83" data-ar="الغسيل والفرز">Cleaning &amp; grading</b><p data-k="t84" data-ar="خطوط تنظيف تستبعد الثمار غير الناضجة وتفرز حسب الحجم.">Cleaning lines remove immature crops; product graded by size.</p></div>
      <div class="pstep"><div class="node"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M12 2v20M4.9 4.9l14.2 14.2M2 12h20M4.9 19.1 19.1 4.9"/><path d="m9 4 3 2 3-2M9 20l3-2 3 2M4 9l2 3-2 3M20 9l-2 3 2 3"/></svg></div><span data-k="t85" data-ar="04" class="mono">04</span><b data-k="t86" data-ar="التجميد الفردي IQF">IQF freezing</b><p data-k="t87" data-ar="تجميد كل قطعة على حدة خلال ساعات من الحصاد.">Each piece frozen individually within hours of harvest.</p></div>
      <div class="pstep"><div class="node"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="m3 8 9 5 9-5M12 13v8"/></svg></div><span data-k="t88" data-ar="05" class="mono">05</span><b data-k="t89" data-ar="التعبئة">Packing</b><p data-k="t90" data-ar="ماكينات متخصصة وخامات آمنة غذائيًا — تجزئة وجملة وعلامة خاصة.">Specialised machinery &amp; food-safe materials — retail, bulk, private label.</p></div>
      <div class="pstep"><div class="node"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M2 17h13V6H2zM15 10h4l3 3v4h-7"/><circle cx="6" cy="18" r="2"/><circle cx="18" cy="18" r="2"/></svg></div><span data-k="t91" data-ar="06" class="mono">06</span><b data-k="t92" data-ar="التخزين والتصدير">Cold storage &amp; export</b><p data-k="t93" data-ar="تخزين عند −18° وشحن بحاويات مبردة إلى أكثر من 50 دولة.">Held at −18°C and shipped in reefer containers to 50+ countries.</p></div>
    </div>
    <div class="cold-note rv"><span data-k="t94" data-ar="تُحفظ عند">Held at</span><span data-k="t95" data-ar="−18°C" class="cn-chip" dir="ltr">−18°C</span><span data-k="t96" data-ar="من خط الإنتاج حتى ميناء الوصول — سلسلة التبريد لا تنقطع.">from the production line to the port of discharge — the cold chain never breaks.</span></div>
  </div>
</section>

<!-- ============ 03 PRODUCTS ============ -->
<section class="sec products" id="products">
  <div class="wrap">
    <div class="sec-head">
      <div>
        <div class="sh rv"><span data-k="t97" data-ar="03" class="idx">03</span><span class="rule"></span><span data-k="t98" class="mono" data-ar="المنتجات">Product range</span></div>
        <h2 data-k="t99" class="h2 rv d1" data-ar="14 منتجًا. عبوة تجزئة واحدة <span class='accent'>بمعيار واحد.</span>">14 SKUs. One retail pack, <span class="accent">one standard.</span></h2>
      </div>
      <p data-k="t100" class="lead rv d2" data-ar="العبوات الجديدة لفروستي — اقلب أي عبوة لترى الوجه الخلفي بالمكونات والقيم الغذائية وطريقة التحضير، أو افتح بطاقة المواصفات الكاملة وأضف المنتج لطلب عرض السعر.">The new Frosty retail packs. Flip any pack to see the back panel — ingredients, nutrition facts and preparation — or open the full spec sheet and add the product to your quotation.</p>
    </div>
    <div class="p-tools rv">
      <div class="tabs" id="tabs">
        <button class="tab on" data-f="all"><span data-k="t101" data-ar="الكل">All</span><small data-k="t102" data-ar="14">14</small></button>
        <button class="tab" data-f="veg"><span data-k="t103" data-ar="خضروات">Vegetables</span><small data-k="t104" data-ar="11">11</small></button>
        <button class="tab" data-f="fruit"><span data-k="t105" data-ar="فواكه">Fruits</span><small data-k="t106" data-ar="2">2</small></button>
        <button class="tab" data-f="potato"><span data-k="t107" data-ar="بطاطس">Potato</span><small data-k="t108" data-ar="1">1</small></button>
      </div>
      <div class="face-switch"><span data-k="t109" data-ar="عرض العبوات:">Show packs:</span><div class="seg" id="globalFace"><button data-k="t110" class="on" data-face="front" data-ar="الوجه الأمامي">Front</button><button data-k="t111" data-face="back" data-ar="الوجه الخلفي">Back</button></div></div>
    </div>
    <div class="p-grid" id="pGrid"></div>
    <p class="p-note rv"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg><span data-k="t112" data-ar="العبوات المعروضة عبوات تجزئة 400 جم (البطاطس 2.5 كجم). كل الأصناف متاحة أيضًا بصيغ الجملة وخدمات الطعام والعلامة الخاصة.">Packs shown are 400 g retail (fries 2.5 kg). Every line is also available in food-service, bulk and private-label formats.</span></p>
  </div>
</section>

<!-- ============ 04 SEASONALITY ============ -->
<section class="sec season" id="seasonality">
  <div class="wrap planner">
    <div>
      <div class="sh rv"><span data-k="t113" data-ar="04" class="idx">04</span><span class="rule"></span><span data-k="t114" class="mono" data-ar="المواسم">Seasonality</span></div>
      <h2 data-k="t115" class="h2 rv d1" data-ar="خطط لمشترياتك حول <span class='accent'>الحصاد.</span>">Plan procurement around <span class="accent">the harvest.</span></h2>
      <p data-k="t116" class="lead rv d2" data-ar="نجمّد في ذروة الحصاد المصري. اختر شهرًا لترى ما يُحصد فيه وما يليه.">We freeze at the peak of Egypt's harvest. Pick a month to see what's being harvested — and what comes next.</p>
      <div class="pl-note rv d3">
        <span><i data-k="t117" data-ar="1">1</i><span data-k="t118" data-ar="الحجز قبل بداية الموسم يضمن أفضل المحصول.">Booking before a window opens secures the best of the crop.</span></span>
        <span><i data-k="t119" data-ar="2">2</i><span data-k="t120" data-ar="كل الأصناف متاحة طوال العام من المخزون المجمد.">Every line stays available year-round from frozen stock.</span></span>
      </div>
    </div>
    <div class="pl-card rv d1">
      <div class="months-bar" id="monthsBar" role="tablist" aria-label="Months"></div>
      <div class="pl-body" id="plBody"></div>
      <div data-k="t121" class="pl-foot" data-ar="الخضار المشكل والبطاطس الفرايز متاحة طوال العام.">Mixed Vegetables and French Fries are supplied year-round.</div>
    </div>
  </div>
</section>

<!-- ============ 05 CAPABILITIES ============ -->
<section class="sec" id="capabilities" style="padding-top:0">
  <div class="wrap">
    <div class="sec-head">
      <div>
        <div class="sh rv"><span data-k="t122" data-ar="05" class="idx">05</span><span class="rule"></span><span data-k="t123" class="mono" data-ar="حلول الأعمال">Business solutions</span></div>
        <h2 data-k="t124" class="h2 rv d1" data-ar="منشأة واحدة. <span class='accent'>أربع طرق</span> لتوريد سوقك.">One facility. <span class="accent">Four ways</span> to supply your market.</h2>
      </div>
      <p data-k="t125" class="lead rv d2" data-ar="من رفوف السوبر ماركت إلى المطابخ المركزية وخطوط التصنيع — نفس الخطوط المعتمدة، بالصيغة التي يحتاجها عملك.">From supermarket shelves to central kitchens and processing lines — the same certified lines, in the format your business needs.</p>
    </div>
    <div class="caps">
      <div class="cap rv"><div class="ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M6 3h12l1 5H5z"/><path d="M5 8v12h14V8M9 12h6"/></svg></div><h3 data-k="t126" data-ar="عبوات التجزئة">Retail packs</h3><p data-k="t127" data-ar="عبوات استهلاكية بعلامة فروستي، بتصميم ثنائي اللغة جاهز للرفوف في أسواق التصدير.">Consumer bags under the Frosty brand — bilingual, shelf-ready artwork for export markets.</p><span data-k="t128" data-ar="20 × 400 g · 1 × 1 kg" class="spec">20 × 400 g · 1 × 1 kg</span></div>
      <div class="cap rv d1"><div class="ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M20.6 13.4 13.4 20.6a2 2 0 0 1-2.8 0L3 13V3h10l7.6 7.6a2 2 0 0 1 0 2.8z"/><circle cx="7.5" cy="7.5" r="1.5"/></svg></div><h3 data-k="t129" data-ar="العلامة الخاصة">Private label</h3><p data-k="t130" data-ar="علامتك التجارية على منتجاتنا — عبوات بتصميمك ومواصفاتك من نفس الخطوط المعتمدة.">Your brand, our crops and certified lines — packs built to your artwork and specifications.</p><span data-k="t131" data-ar="400 g · 1 kg · 2.5 kg · 10 kg" class="spec">400 g · 1 kg · 2.5 kg · 10 kg</span></div>
      <div class="cap rv d2"><div class="ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M3 11h18M5 11a7 7 0 0 1 14 0M12 4V2M4 15h16l-1 5H5z"/></svg></div><h3 data-k="t132" data-ar="الجملة وخدمات الطعام">Food service &amp; bulk</h3><p data-k="t133" data-ar="صيغ مخصصة للفنادق والمطاعم وسلاسل الوجبات السريعة والمطابخ المركزية.">Catering formats for hotels, restaurants, QSR chains and central kitchens.</p><span data-k="t134" data-ar="4 × 2.5 kg · 1 × 10 kg" class="spec">4 × 2.5 kg · 1 × 10 kg</span></div>
      <div class="cap rv d3"><div class="ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><ellipse cx="12" cy="5" rx="7" ry="2.5"/><path d="M5 5v14c0 1.4 3.1 2.5 7 2.5s7-1.1 7-2.5V5M5 12c0 1.4 3.1 2.5 7 2.5s7-1.1 7-2.5"/></svg></div><h3 data-k="t135" data-ar="التصنيع الغذائي">Industrial</h3><p data-k="t136" data-ar="براميل محلول ملحي وشراب للمصانع ومعيدي التعبئة.">Brine &amp; syrup drums for food processors and re-packers.</p><span data-k="t137" class="spec" data-ar="براميل 225 كجم (140 كجم صافي)">225 kg drums (140 kg drained)</span></div>
    </div>
  </div>
</section>

<!-- ============ 06 LOGISTICS ============ -->
<section class="sec dark logi" id="logistics">
  <div class="wrap">
    <div class="sec-head">
      <div>
        <div class="sh rv"><span data-k="t138" data-ar="06" class="idx">06</span><span class="rule"></span><span data-k="t139" class="mono" data-ar="التعبئة والشحن">Packing &amp; shipping</span></div>
        <h2 data-k="t140" class="h2 rv d1" data-ar="مواصفات تصدير <span class='accent'>واضحة من البداية.</span>">Export specs, <span class="accent">clear from day one.</span></h2>
      </div>
      <p data-k="t141" class="lead rv d2" data-ar="صيغ تعبئة قياسية وأحمال حاويات معروفة مسبقًا — حتى يتمكن فريق المشتريات لديك من التخطيط والتسعير بثقة.">Standard packing configurations and known container loads — so your procurement team can plan and price with confidence.</p>
    </div>
    <div class="logi-grid">
      <div class="panel rv">
        <h3><span data-k="t142" data-ar="المنتجات المجمدة — كراتين">Frozen products — cartons</span><span data-k="t143" class="mono" data-ar="قياسي">Standard</span></h3>
        <table class="spec-table">
          <tr><td data-k="t144" data-ar="20 × 400 g">20 × 400 g</td><td><span data-k="t145" data-ar="كرتونة تجزئة">Retail carton</span><span data-k="t146" data-ar="RETAIL" class="tagc">RETAIL</span></td></tr>
          <tr><td data-k="t147" data-ar="1 × 1 kg">1 × 1 kg</td><td><span data-k="t148" data-ar="كرتونة تجزئة">Retail carton</span><span data-k="t149" data-ar="RETAIL" class="tagc">RETAIL</span></td></tr>
          <tr><td data-k="t150" data-ar="4 × 2.5 kg">4 × 2.5 kg</td><td><span data-k="t151" data-ar="كرتونة خدمات طعام">Food-service carton</span><span data-k="t152" data-ar="HORECA" class="tagc">HORECA</span></td></tr>
          <tr><td data-k="t153" data-ar="1 × 10 kg">1 × 10 kg</td><td><span data-k="t154" data-ar="كرتونة جملة">Bulk carton</span><span data-k="t155" data-ar="BULK" class="tagc">BULK</span></td></tr>
        </table>
        <h3 style="margin-top:30px"><span data-k="t156" data-ar="المحلول الملحي والشراب — براميل">Brine &amp; syrup — drums</span><span data-k="t157" class="mono" data-ar="صناعي">Industrial</span></h3>
        <table class="spec-table">
          <tr><td data-k="t158" data-ar="225 kg">225 kg</td><td data-k="t159" data-ar="الوزن القائم / برميل">Gross weight / drum</td></tr>
          <tr><td data-k="t160" data-ar="140 kg">140 kg</td><td data-k="t161" data-ar="الوزن المصفّى / برميل">Drained weight / drum</td></tr>
        </table>
      </div>
      <div class="panel rv d1">
        <h3><span data-k="t162" data-ar="تحميل الحاويات">Container loading</span><span data-k="t163" class="mono" data-ar="لكل حاوية">Per container</span></h3>
        <div class="containers">
          <div class="ctn"><svg viewBox="0 0 132 44" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="1" y="4" width="130" height="36" rx="2"/><path d="M9 8v28M17 8v28M25 8v28M33 8v28M41 8v28M49 8v28M57 8v28M65 8v28M73 8v28M81 8v28M89 8v28M97 8v28M105 8v28M113 8v28M121 8v28" opacity=".45"/></svg><b data-k="t164" data-ar="40 قدم مبردة">40 ft Reefer</b><div class="v"><span data-k="t165" data-ar="2,400–2,600">2,400–2,600</span><small data-k="t166" data-ar="كرتونة 10 كجم">cartons · 10 kg</small></div><p data-k="t167" data-ar="أو 2,800 كرتونة 8 كجم">or 2,800 cartons · 8 kg</p></div>
          <div class="ctn"><svg viewBox="0 0 132 44" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="1" y="4" width="66" height="36" rx="2"/><path d="M9 8v28M17 8v28M25 8v28M33 8v28M41 8v28M49 8v28M57 8v28" opacity=".45"/></svg><b data-k="t168" data-ar="20 قدم مبردة">20 ft Reefer</b><div class="v"><span data-k="t169" data-ar="1,000–1,200">1,000–1,200</span><small data-k="t170" data-ar="كرتونة">cartons</small></div><p data-k="t171" data-ar="مناسبة للطلبات التجريبية">Suited to trial orders</p></div>
          <div class="ctn dry"><svg viewBox="0 0 132 44" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="1" y="4" width="130" height="36" rx="2"/><circle cx="14" cy="22" r="7"/><circle cx="32" cy="22" r="7"/><circle cx="50" cy="22" r="7"/><circle cx="68" cy="22" r="7"/><circle cx="86" cy="22" r="7"/><circle cx="104" cy="22" r="7"/><circle cx="120" cy="22" r="6"/></svg><b data-k="t172" data-ar="40 قدم جافة">40 ft Dry</b><div class="v"><span data-k="t173" data-ar="80">80</span><small data-k="t174" data-ar="برميل">drums</small></div><p data-k="t175" data-ar="منتجات المحلول الملحي والشراب">Brine &amp; syrup products</p></div>
          <div class="ctn dry"><svg viewBox="0 0 132 44" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="1" y="4" width="66" height="36" rx="2"/><circle cx="14" cy="22" r="7"/><circle cx="32" cy="22" r="7"/><circle cx="50" cy="22" r="7"/></svg><b data-k="t176" data-ar="20 قدم جافة">20 ft Dry</b><div class="v"><span data-k="t177" data-ar="20">20</span><small data-k="t178" data-ar="برميل">drums</small></div><p data-k="t179" data-ar="منتجات المحلول الملحي والشراب">Brine &amp; syrup products</p></div>
        </div>
        <div class="incoterms"><span data-k="t180" data-ar="شروط التسليم:">Incoterms:</span><b data-k="t181" data-ar="FOB Alexandria" class="main">FOB Alexandria</b><b data-k="t182" data-ar="CIF">CIF</b><b data-k="t183" data-ar="CFR">CFR</b><b data-k="t184" data-ar="EXW">EXW</b><b data-k="t185" data-ar="DDP">DDP</b></div>
      </div>
    </div>
  </div>
</section>

<!-- ============ 07 MARKETS ============ -->
<section class="sec markets" id="markets">
  <div class="wrap">
    <div class="mk-panel rv">
      <div class="mk-side">
        <div class="sh" style="margin-bottom:0"><span data-k="t186" data-ar="07" class="idx">07</span><span class="rule"></span><span data-k="t187" class="mono" data-ar="الأسواق العالمية">Global markets</span></div>
        <h2 data-k="t188" class="h2" data-ar="من الإسكندرية <span class='accent'>إلى العالم.</span>">From Alexandria <span class="accent">to the world.</span></h2>
        <p data-k="t189" class="lead" data-ar="شحنات مبردة يديرها فريق لوجستي خبير — من مصنعنا حتى ميناء الوصول.">Reefer shipments managed by an experienced logistics team — from our plant to your port of discharge.</p>
        <div class="mk-stats"><div><b data-k="t190" data-ar="50+">50+</b><span data-k="t191" data-ar="دولة">countries</span></div><div><b data-k="t192" data-ar="5">5</b><span data-k="t193" data-ar="قارات">continents</span></div><div><b data-k="t194" data-ar="−18°" dir="ltr">−18°</b><span data-k="t195" data-ar="شحن مبرد">reefer</span></div></div>
        <div class="rg-list" id="rgList"></div>
        <p class="rg-countries" id="rgCountries"></p>
      </div>
      <div class="map-box" id="mapBox">
        <svg id="map" viewBox="0 0 160 76" aria-label="Frosty Foods export markets map"></svg>
        <div data-k="t196" class="map-label" id="mapLabel" data-ar="الإسكندرية">Alexandria</div>
      </div>
    </div>
  </div>
</section>

<!-- ============ 08 QUALITY ============ -->
<section class="sec quality" id="quality">
  <div class="wrap">
    <div class="sec-head">
      <div>
        <div class="sh rv"><span data-k="t197" data-ar="08" class="idx">08</span><span class="rule"></span><span data-k="t198" class="mono" data-ar="الجودة والشهادات">Quality &amp; certification</span></div>
        <h2 data-k="t199" class="h2 rv d1" data-ar="مُدقَّقة. مُعتمَدة. <span class='accent'>موثوقة.</span>">Audited. Certified. <span class="accent">Trusted.</span></h2>
      </div>
      <p data-k="t200" class="lead rv d2" data-ar="أنظمة سلامة غذاء معترف بها دوليًا تدعم كل عبوة — وهي المعايير التي تطلبها كبرى سلاسل التجزئة في أوروبا وأمريكا الشمالية.">Internationally recognised food-safety systems stand behind every pack — the standards required by leading retail chains in Europe and North America.</p>
    </div>
    <div class="cert-rail rv">
      <div class="cert"><img data-ik="i10" src="<?php echo $frosty_assets; ?>img/certs/cert-0.png" alt="BRC Food"><b data-k="t201" data-ar="BRC Food">BRC Food</b><span data-k="t202" data-ar="المعيار العالمي لسلامة الغذاء">Global Standard for Food Safety</span></div>
      <div class="cert"><img data-ik="i11" src="<?php echo $frosty_assets; ?>img/certs/cert-2.png" alt="ISO 22000"><b data-k="t203" data-ar="ISO 22000">ISO 22000</b><span data-k="t204" data-ar="إدارة سلامة الغذاء">Food Safety Management</span></div>
      <div class="cert"><img data-ik="i12" src="<?php echo $frosty_assets; ?>img/certs/cert-3.png" alt="ISO 9001:2015"><b data-k="t205" data-ar="ISO 9001:2015">ISO 9001:2015</b><span data-k="t206" data-ar="إدارة الجودة">Quality Management</span></div>
      <div class="cert"><img data-ik="i13" src="<?php echo $frosty_assets; ?>img/certs/cert-4.png" alt="FSSC 22000"><b data-k="t207" data-ar="FSSC 22000">FSSC 22000</b><span data-k="t208" data-ar="شهادة نظام سلامة الغذاء">Food Safety System</span></div>
      <div class="cert"><img data-ik="i14" src="<?php echo $frosty_assets; ?>img/certs/cert-1.png" alt="FDA"><b data-k="t209" data-ar="FDA">FDA</b><span data-k="t210" data-ar="مسجلة لدى FDA الأمريكية">U.S. FDA registered</span></div>
      <div class="cert"><img data-ik="i15" src="<?php echo $frosty_assets; ?>img/certs/cert-5.png" alt="KLBD Kosher"><b data-k="t211" data-ar="KLBD">KLBD</b><span data-k="t212" data-ar="شهادة كوشر">Kosher certified</span></div>
    </div>
    <div class="q-bottom">
      <div class="q-flow rv">
        <div class="q-step"><span data-k="t213" data-ar="01" class="n">01</span><b data-k="t214" data-ar="الاختيار">Selection</b><p data-k="t215" data-ar="أفضل مناطق الزراعة مع انتقاء دقيق للمحاصيل والبذور.">Premium growing regions; careful crop &amp; seed selection.</p></div>
        <div class="q-step"><span data-k="t216" data-ar="02" class="n">02</span><b data-k="t217" data-ar="الحصاد">Harvesting</b><p data-k="t218" data-ar="خطوط تنظيف تستبعد الثمار غير الناضجة.">Cleaning lines remove immature crops.</p></div>
        <div class="q-step"><span data-k="t219" data-ar="03" class="n">03</span><b data-k="t220" data-ar="التعبئة">Packing</b><p data-k="t221" data-ar="ماكينات متخصصة وخامات آمنة غذائيًا.">Specialised machinery, food-safe materials.</p></div>
        <div class="q-step"><span data-k="t222" data-ar="04" class="n">04</span><b data-k="t223" data-ar="اللوجستيات">Logistics</b><p data-k="t224" data-ar="سلامة المنتج محفوظة حتى أكثر من 50 دولة.">Integrity kept all the way to 50+ countries.</p></div>
      </div>
      <div class="q-quote rv d1"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M10 7H6a3 3 0 0 0-3 3v7h7v-7H6a1 1 0 0 1 1-1h3zm11 0h-4a3 3 0 0 0-3 3v7h7v-7h-4a1 1 0 0 1 1-1h3z"/></svg><p data-k="t225" data-ar="«لن تجد كتلة متجمدة في أي عبوة من عبواتنا.»">"You'll never find a solid block of product in any of our bags."</p><span data-k="t226" data-ar="— وعد فروستي IQF">— The Frosty IQF promise</span></div>
    </div>
  </div>
</section>

<!-- ============ 09 RFQ ============ -->
<section class="sec rfq" id="rfq">
  <div class="wrap">
    <div class="rfq-shell rv">
      <div class="rfq-side">
        <div>
          <div class="sh"><span data-k="t227" data-ar="09" class="idx">09</span><span class="rule"></span><span data-k="t228" class="mono" data-ar="طلب عرض سعر">Request for quotation</span></div>
          <h2 data-k="t229" class="h2" data-ar="أخبرنا بما يحتاجه سوقك.">Tell us what your market needs.</h2>
        </div>
        <ol class="flow">
          <li><span data-k="t230" data-ar="01" class="n">01</span><div><b data-k="t231" data-ar="الاستفسار">Inquiry</b><p data-k="t232" data-ar="أرسل المنتجات والكميات والوجهة.">Send products, volumes &amp; destination.</p></div></li>
          <li><span data-k="t233" data-ar="02" class="n">02</span><div><b data-k="t234" data-ar="عرض السعر">Quotation</b><p data-k="t235" data-ar="عرض مخصص بالتعبئة وشروط التسليم ونوافذ المواسم.">Tailored offer with packing, incoterms &amp; season windows.</p></div></li>
          <li><span data-k="t236" data-ar="03" class="n">03</span><div><b data-k="t237" data-ar="العينات والتعاقد">Samples &amp; contract</b><p data-k="t238" data-ar="عينات واعتماد المواصفات وشروط التعاقد.">Samples, spec sign-off and contract terms.</p></div></li>
          <li><span data-k="t239" data-ar="04" class="n">04</span><div><b data-k="t240" data-ar="الإنتاج والجودة">Production &amp; QC</b><p data-k="t241" data-ar="إنتاج IQF معتمد مع رقابة جودة كاملة.">Certified IQF production with full quality control.</p></div></li>
          <li><span data-k="t242" data-ar="05" class="n">05</span><div><b data-k="t243" data-ar="الشحن والمستندات">Shipping &amp; documents</b><p data-k="t244" data-ar="تحميل مبرد ومستندات تصدير ومتابعة حتى التسليم.">Reefer loading, export documents &amp; delivery follow-up.</p></div></li>
        </ol>
        <div class="direct">
          <a data-lk="l5" href="mailto:export@frosty-foods.com"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/></svg><span data-k="t245" data-ar="export@frosty-foods.com">export@frosty-foods.com</span></a>
          <a data-lk="l6" href="tel:+2034854400" dir="ltr"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg><span data-k="t246" data-ar="+2 034854400">+2 034854400</span></a>
        </div>
      </div>
      <form class="rfq-form" id="rfqForm" novalidate>
        <div class="form-head"><b data-k="t247" data-ar="نموذج طلب عرض السعر">Quotation request</b><span id="stepLbl">Step 1 of 2</span></div>
        <ol class="stepper" id="stepper">
          <li class="on" data-s="1"><i data-k="t248" data-ar="1">1</i><span data-k="t249" data-ar="الشركة والتواصل">Company &amp; contact</span></li>
          <li data-s="2"><i data-k="t250" data-ar="2">2</i><span data-k="t251" data-ar="تفاصيل الطلب">Order details</span></li>
        </ol>
        <div class="fstep on" data-step="1">
        <div class="row2">
          <div class="fld"><label data-k="t252" for="fName" data-ar="اسم المسؤول *">Contact name *</label><input id="fName" required autocomplete="name"></div>
          <div class="fld"><label data-k="t253" for="fCompany" data-ar="الشركة *">Company *</label><input id="fCompany" required autocomplete="organization"></div>
        </div>
        <div class="row2">
          <div class="fld"><label data-k="t254" for="fEmail" data-ar="البريد الإلكتروني للعمل *">Business email *</label><input id="fEmail" type="email" required autocomplete="email"></div>
          <div class="fld"><label data-k="t255" for="fPhone" data-ar="هاتف / واتساب">Phone / WhatsApp</label><input id="fPhone" type="tel" autocomplete="tel"></div>
        </div>
        <div class="row2">
          <div class="fld"><label data-k="t256" for="fCountry" data-ar="الدولة *">Country *</label><select id="fCountry" required></select></div>
          <div class="fld"><label data-k="t257" for="fType" data-ar="نوع النشاط *">Business type *</label>
            <select id="fType" required>
              <option data-k="t258" value="" data-ar="اختر…">Select…</option>
              <option data-k="t259" value="Importer" data-ar="مستورد">Importer</option>
              <option data-k="t260" value="Distributor / Wholesaler" data-ar="موزع / تاجر جملة">Distributor / Wholesaler</option>
              <option data-k="t261" value="Retail chain" data-ar="سلسلة تجزئة / سوبر ماركت">Retail chain / Supermarket</option>
              <option data-k="t262" value="Food service / HoReCa" data-ar="خدمات طعام / فنادق ومطاعم">Food service / HoReCa</option>
              <option data-k="t263" value="Food industry" data-ar="صناعات غذائية">Food industry / Processing</option>
              <option data-k="t264" value="Private label" data-ar="مشروع علامة خاصة">Private label project</option>
            </select></div>
        </div>
          <div class="step-nav"><button type="button" class="btn btn-navy" id="toStep2"><span data-k="t265" data-ar="التالي: تفاصيل الطلب">Next: order details</span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14M13 6l6 6-6 6"/></svg></button><p data-k="t266" data-ar="الخطوة التالية: المنتجات والكميات والتعبئة.">Next: products, volumes and packing.</p></div>
        </div>
        <div class="fstep" data-step="2">
        <div class="fld"><label data-k="t267" data-ar="المنتجات المطلوبة *">Products of interest *</label><div class="chips" id="chips"></div></div>
        <div class="row2">
          <div class="fld"><label data-k="t268" for="fQty" data-ar="الكمية التقديرية">Estimated volume</label>
            <select id="fQty">
              <option data-k="t269" value="" data-ar="اختر…">Select…</option>
              <option data-k="t270" value="Trial order / samples" data-ar="طلب تجريبي / عينات">Trial order / samples</option>
              <option data-k="t271" value="1 x 20ft reefer" data-ar="حاوية 20 قدم">1 × 20 ft reefer</option>
              <option data-k="t272" value="1 x 40ft reefer" data-ar="حاوية 40 قدم">1 × 40 ft reefer</option>
              <option data-k="t273" value="2-5 containers" data-ar="2–5 حاويات">2–5 containers</option>
              <option data-k="t274" value="5+ containers / annual contract" data-ar="أكثر من 5 حاويات / تعاقد سنوي">5+ containers / annual contract</option>
            </select></div>
          <div class="fld"><label data-k="t275" for="fInco" data-ar="شرط التسليم">Preferred incoterm</label>
            <select id="fInco">
              <option data-k="t276" value="" data-ar="اختر…">Select…</option>
              <option data-k="t277" data-ar="FOB Alexandria">FOB Alexandria</option><option data-k="t278" data-ar="CIF">CIF</option><option data-k="t279" data-ar="CFR">CFR</option><option data-k="t280" data-ar="EXW">EXW</option><option data-k="t281" data-ar="DDP">DDP</option>
              <option data-k="t282" value="Not sure" data-ar="غير محدد بعد">Not sure yet</option>
            </select></div>
        </div>
        <div class="row2">
          <div class="fld"><label data-k="t283" for="fPack" data-ar="التعبئة المفضلة">Packing format</label>
            <select id="fPack">
              <option data-k="t284" value="" data-ar="اختر…">Select…</option>
              <option data-k="t285" value="Retail 20x400g" data-ar="تجزئة — 20×400 جم">Retail — 20 × 400 g</option>
              <option data-k="t286" value="Retail 1kg" data-ar="تجزئة — 1 كجم">Retail — 1 kg</option>
              <option data-k="t287" value="Food service 4x2.5kg" data-ar="خدمات طعام — 4×2.5 كجم">Food service — 4 × 2.5 kg</option>
              <option data-k="t288" value="Bulk 10kg" data-ar="جملة — 10 كجم">Bulk — 10 kg</option>
              <option data-k="t289" value="Drums" data-ar="براميل — محلول ملحي / شراب">Drums — brine / syrup</option>
              <option data-k="t290" value="Private label" data-ar="علامة خاصة">Private label — custom</option>
            </select></div>
          <div class="fld"><label data-k="t291" for="fPort" data-ar="ميناء الوصول">Destination port</label><input id="fPort"></div>
        </div>
        <div class="fld"><label data-k="t292" for="fMsg" data-ar="تفاصيل إضافية">Additional details</label><textarea data-k="t293" data-kt="ph" id="fMsg" data-ph-ar="المواصفات، الدرجات، مواعيد التسليم…" placeholder="Specs, grades, delivery windows…"></textarea></div>
        <div class="submit">
          <button type="button" class="btn btn-line" id="toStep1"><span data-k="t294" data-ar="رجوع">Back</span></button>
          <button type="submit" class="btn btn-navy"><span data-k="t295" data-ar="أرسل الطلب">Send request</span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14M13 6l6 6-6 6"/></svg></button>
          <p data-k="t296" data-ar="يفتح تطبيق البريد برسالة منسقة موجهة لفريق التصدير.">Opens your email client with a structured RFQ addressed to our export team.</p>
        </div>
        </div>
        <div class="toast" id="toast"></div>
      </form>
    </div>
  </div>
</section>

<!-- ============ 10 FAQ ============ -->
<section class="sec" id="faq">
  <div class="wrap">
    <div class="sec-head">
      <div>
        <div class="sh rv"><span data-k="t297" data-ar="10" class="idx">10</span><span class="rule"></span><span data-k="t298" class="mono" data-ar="أسئلة المستوردين">Buyer FAQ</span></div>
        <h2 data-k="t299" class="h2 rv d1" data-ar="أسئلة يطرحها <span class='accent'>المشترون.</span>">Questions buyers <span class="accent">ask us.</span></h2>
      </div>
      <p data-k="t300" class="lead rv d2" data-ar="إجابات مباشرة عن مستندات التصدير والحد الأدنى للطلب والعلامة الخاصة وشروط التسليم.">Straight answers on export documents, minimum orders, private label and incoterms.</p>
    </div>
    <div class="faq-shell">
      <div class="fq-list rv" id="fqList">
        <div class="fq on" data-i="0"><button class="fq-q" aria-expanded="true"><span class="n">01</span><span data-ar="ما مستندات التصدير التي توفرونها؟">What export documents do you provide?</span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14M13 6l6 6-6 6"/></svg></button><div class="fq-a" data-ar="ملف تصدير كامل مع كل شحنة: فاتورة تجارية، بيان تعبئة، شهادة منشأ، شهادات صحية وصحة نباتية، وتقارير تحاليل عند الطلب — مدعومة بشهادات BRC وISO 22000 وFSSC 22000 وFDA وكوشر.">A full export dossier per shipment: commercial invoice, packing list, certificate of origin, health and phytosanitary certificates, plus analysis reports on request — backed by our BRC, ISO 22000, FSSC 22000, FDA and Kosher certifications.</div></div>
        <div class="fq" data-i="1"><button class="fq-q" aria-expanded="false"><span class="n">02</span><span data-ar="ما الحد الأدنى لكمية الطلب؟">What is the minimum order quantity?</span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14M13 6l6 6-6 6"/></svg></button><div class="fq-a" data-ar="عادةً حاوية كاملة (20 أو 40 قدم مبردة)، ويمكن تجهيز حاويات مشكّلة من عدة منتجات. اذكر كمياتك في نموذج الطلب وسنرتب الخيار الأنسب.">Typically one full container (20 ft or 40 ft reefer); mixed-product containers are possible. Share your target volumes in the RFQ and we'll structure the best option for your market.</div></div>
        <div class="fq" data-i="2"><button class="fq-q" aria-expanded="false"><span class="n">03</span><span data-ar="هل تنتجون بعلامة خاصة؟">Do you produce private label?</span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14M13 6l6 6-6 6"/></svg></button><div class="fq-a" data-ar="نعم — نعبئ بعلامتك وتصميمك في عبوات 400 جم أو 1 كجم أو 2.5 كجم أو 10 كجم، على نفس خطوط الإنتاج المعتمدة لعلامة فروستي.">Yes — we pack under your brand and artwork in 400 g, 1 kg, 2.5 kg or 10 kg formats, produced on the same certified lines as the Frosty brand.</div></div>
        <div class="fq" data-i="3"><button class="fq-q" aria-expanded="false"><span class="n">04</span><span data-ar="ما شروط التسليم المتاحة؟">Which incoterms do you work with?</span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14M13 6l6 6-6 6"/></svg></button><div class="fq-a" data-ar="نقدّم عروضنا عادة FOB الإسكندرية أو CIF/CFR حتى ميناء الوصول، ويمكن بحث EXW أو DDP حسب الوجهة.">We commonly quote FOB Alexandria and CIF/CFR to your port, and can discuss EXW or DDP depending on the destination.</div></div>
        <div class="fq" data-i="4"><button class="fq-q" aria-expanded="false"><span class="n">05</span><span data-ar="هل يمكن الحصول على عينات قبل التعاقد؟">Can we receive samples before committing?</span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14M13 6l6 6-6 6"/></svg></button><div class="fq-a" data-ar="بالتأكيد — العينات والمواصفات الفنية الكاملة جزء من مسار التعامل القياسي قبل توقيع أي عقد.">Yes — samples and full technical specifications are part of our standard flow before any contract is signed.</div></div>
        <div class="fq" data-i="5"><button class="fq-q" aria-expanded="false"><span class="n">06</span><span data-ar="ما أفضل وقت لحجز المحاصيل الموسمية؟">When should we book seasonal crops?</span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14M13 6l6 6-6 6"/></svg></button><div class="fq-a" data-ar="قبل بداية نافذة الحصاد — راجع مخطط المواسم أعلاه. الفراولة قبل يناير، والبامية والملوخية قبل يونيو، والرمان قبل سبتمبر.">Before the harvest window opens — see the seasonality planner above. Strawberry before January; okra and molokhia before June; pomegranate before September.</div></div>
      </div>
      <aside class="faq-panel rv d1" aria-live="polite">
      <div id="fpInner"></div>
      <div class="fp-foot"><span data-k="t301" data-ar="سؤال آخر؟">Another question?</span><a data-lk="l7" href="mailto:export@frosty-foods.com"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/></svg><span data-k="t302" data-ar="export@frosty-foods.com">export@frosty-foods.com</span></a></div>
    </aside>
    </div>
    <div class="consumer rv"><span><b data-k="t303" data-ar="تشتري للمنزل؟">Shopping for your home?</b> <span data-k="t304" data-ar="راسلنا لنرشدك لأقرب منفذ.">Message us for the nearest store.</span></span><span class="links"><a data-k="t305" data-ar="Facebook" data-lk="l8" href="https://www.facebook.com/frostyfoodseg" target="_blank" rel="noopener">Facebook</a><a data-k="t306" data-ar="Instagram" data-lk="l9" href="https://www.instagram.com/frostyfoods.eg/" target="_blank" rel="noopener">Instagram</a></span></div>
  </div>
</section>

<!-- ============ CONTACT ============ -->
<section class="sec contact" id="contact">
  <div class="wrap">
    <div class="offices">
      <div class="office rv"><span data-k="t307" class="mono" data-ar="المكتب الرئيسي">Head office</span><h3 data-k="t308" data-ar="الإسكندرية">Alexandria</h3><p data-k="t309" data-ar="66 طريق الحرية، العطارين، الإسكندرية، مصر">66 El Horreya Rd., Al Attareen, Alexandria, Egypt</p><a data-lk="l10" class="lnk" href="https://www.google.com/maps/search/?api=1&amp;query=66+El+Horreya+Road+Al+Attareen+Alexandria+Egypt" target="_blank" rel="noopener"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0z"/><circle cx="12" cy="10" r="3"/></svg><span data-k="t310" data-ar="افتح في خرائط جوجل">Open in Google Maps</span></a></div>
      <div class="office rv d1"><span data-k="t311" class="mono" data-ar="المصنع">Factory</span><h3 data-k="t312" data-ar="برج العرب الجديدة">New Borg El Arab</h3><p data-k="t313" data-ar="قطعة 15–16، بلوك 3، المنطقة الصناعية الرابعة، برج العرب الجديدة، الإسكندرية">Plot 15–16, Block 3, 4th Industrial Zone, New Borg El Arab, Alexandria</p><a data-lk="l11" class="lnk" href="https://www.google.com/maps/search/?api=1&amp;query=Industrial+Zone+4+New+Borg+El+Arab+Alexandria+Egypt" target="_blank" rel="noopener"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0z"/><circle cx="12" cy="10" r="3"/></svg><span data-k="t314" data-ar="افتح في خرائط جوجل">Open in Google Maps</span></a></div>
      <div class="office big rv d2"><span data-k="t315" class="mono" data-ar="مكتب التصدير">Export desk</span><h3 data-k="t316" data-ar="تواصل مباشر">Direct line</h3><p data-k="t317" data-ar="تواصل مباشر مع فريق التصدير — بلا وسطاء.">Talk directly to the export team — no intermediaries.</p><a data-lk="l12" class="v" href="mailto:export@frosty-foods.com"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/></svg><span data-k="t318" data-ar="export@frosty-foods.com">export@frosty-foods.com</span></a><a data-lk="l13" class="v" href="tel:+2034854400" dir="ltr"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg><span data-k="t319" data-ar="+2 034854400">+2 034854400</span></a></div>
    </div>
    <div class="cta-band rv">
      <div class="txt">
        <div class="sh"><span class="idx">—</span><span class="rule"></span><span data-k="t320" class="mono" data-ar="الموسم القادم">Next season</span></div>
        <h2 data-k="t321" class="h2" data-ar="احجز حصتك من <span class='accent'>الحصاد القادم.</span>">Secure your allocation from <span class="accent">the coming harvest.</span></h2>
        <p data-k="t322" data-ar="المحاصيل الموسمية تُحجز سريعًا. أرسل طلبك اليوم ليبدأ فريق التصدير في تجهيز عرضك.">Seasonal crops are allocated early. Send your RFQ today and our export team will start preparing your offer.</p>
        <div class="btns"><a href="#rfq" class="btn btn-primary"><span data-k="t323" data-ar="اطلب عرض سعر">Request a quotation</span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a><a data-k="t324" href="#products" class="btn btn-ghost" data-ar="استعرض المنتجات">Browse products</a></div>
      </div>
      <div class="cta-packs" aria-hidden="true"><img data-ik="i16" src="<?php echo $frosty_assets; ?>img/packs/strawberry-front.webp" alt="" loading="lazy"><img data-ik="i17" src="<?php echo $frosty_assets; ?>img/packs/artichokes-front.webp" alt="" loading="lazy"><img data-ik="i18" src="<?php echo $frosty_assets; ?>img/packs/okra-front.webp" alt="" loading="lazy"></div>
    </div>
  </div>
</section>

<!-- ============ FOOTER ============ -->
<footer class="footer">
  <div class="wrap">
    <div class="f-grid">
      <div class="f-brand">
        <img data-ik="i19" src="<?php echo $frosty_assets; ?>img/logo.png" alt="Frosty Foods">
        <p data-k="t325" data-ar="متخصصو الأغذية المجمدة. فواكه وخضروات مصرية مجمدة بتقنية IQF — من برج العرب إلى أكثر من 50 دولة.">The frozen food specialists. Egyptian IQF fruits and vegetables — from New Borg El Arab to 50+ countries.</p>
        <div class="socials">
          <a data-lk="l14" href="https://www.facebook.com/frostyfoodseg" target="_blank" rel="noopener" aria-label="Facebook"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg></a>
          <a data-lk="l15" href="https://www.instagram.com/frostyfoods.eg/" target="_blank" rel="noopener" aria-label="Instagram"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/></svg></a>
        </div>
      </div>
      <div><h5 data-k="t326" data-ar="الشركة">Company</h5><ul>
        <li><a data-k="t327" href="#company" data-ar="عن فروستي">About Frosty</a></li>
        <li><a data-k="t328" href="#production" data-ar="الإنتاج والتقنية">Production &amp; IQF</a></li>
        <li><a data-k="t329" href="#quality" data-ar="الجودة والشهادات">Quality &amp; certification</a></li>
        <li><a data-k="t330" href="#markets" data-ar="الأسواق العالمية">Global markets</a></li>
        <li><a data-k="t331" href="#contact" data-ar="تواصل معنا">Contact</a></li>
      </ul></div>
      <div><h5 data-k="t332" data-ar="المنتجات">Products</h5><ul id="fProds"></ul></div>
      <div><h5 data-k="t333" data-ar="للمشترين">For buyers</h5><ul>
        <li><a data-k="t334" href="#rfq" data-ar="طلب عرض سعر">Request a quotation</a></li>
        <li><a data-k="t335" href="#capabilities" data-ar="العلامة الخاصة">Private label</a></li>
        <li><a data-k="t336" href="#logistics" data-ar="التعبئة والحاويات">Packing &amp; containers</a></li>
        <li><a data-k="t337" href="#seasonality" data-ar="تقويم المواسم">Seasonality calendar</a></li>
        <li><a data-k="t338" data-ar="export@frosty-foods.com" data-lk="l16" href="mailto:export@frosty-foods.com">export@frosty-foods.com</a></li>
      </ul>
      <div class="f-certs"><img data-ik="i20" src="<?php echo $frosty_assets; ?>img/certs/cert-0.png" alt="BRC"><img data-ik="i21" src="<?php echo $frosty_assets; ?>img/certs/cert-2.png" alt="ISO 22000"><img data-ik="i22" src="<?php echo $frosty_assets; ?>img/certs/cert-3.png" alt="ISO 9001"><img data-ik="i23" src="<?php echo $frosty_assets; ?>img/certs/cert-4.png" alt="FSSC 22000"><img data-ik="i24" src="<?php echo $frosty_assets; ?>img/certs/cert-1.png" alt="FDA"><img data-ik="i25" src="<?php echo $frosty_assets; ?>img/certs/cert-5.png" alt="KLBD"></div></div>
    </div>
    <div class="f-bottom"><span><span data-k="t339" data-ar="©">©</span> <span id="yr"></span> <span data-k="t340" data-ar="فروستي فودز — الإسكندرية، مصر. جميع الحقوق محفوظة.">Frosty Foods — Alexandria, Egypt. All rights reserved.</span></span><span class="f-meta"><span data-k="t341" data-ar="إعادة تصميم: محمد طارق">Redesign concept by Mohamed Tarek</span> · <a href="#dashboard" class="cms-open"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="10" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg><span class="cms-open-t">Dashboard · لوحة التحكم</span></a></span></div>
  </div>
</footer>

<!-- ============ SPEC SHEET MODAL ============ -->
<div class="modal-bg" id="modal" role="dialog" aria-modal="true" aria-labelledby="mName">
  <div class="modal">
    <button class="m-close" id="mClose" aria-label="Close"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M18 6 6 18M6 6l12 12"/></svg></button>
    <div class="m-media">
      <div class="m-views"><div class="m-view"><img data-ik="i26" id="mFront" alt=""><span data-k="t342" data-ar="الأمام">Front</span></div><div class="m-view"><img data-ik="i27" id="mBack" alt=""><span data-k="t343" data-ar="الخلف">Back</span></div></div>
      <p data-k="t344" data-ar="اضغط على أي وجه لتكبيره">Click a panel to enlarge</p>
    </div>
    <div class="m-body">
      <span class="mono" id="mNo"></span>
      <div class="m-title"><h3 id="mName"></h3><span id="mAr"></span></div>
      <p class="m-desc" id="mDesc"></p>
      <table class="sheet"><tbody id="mSheet"></tbody></table>
      <div class="m-ctas"><button class="btn btn-navy" id="mAdd"></button><a data-k="t345" href="#rfq" class="btn btn-line" id="mGo" data-ar="اذهب لنموذج الطلب">Go to RFQ form</a></div>
    </div>
  </div>
</div>
<div class="lightbox" id="lightbox"><img data-ik="i28" id="lbImg" alt=""></div>

<script>
/* ================= DATA ================= */
const P=[
 {id:'artichokes',no:'01',en:'Artichokes',ar:'خرشوف',v:'Premium Frozen Artichokes',va:'خرشوف مجمد فاخر',cat:'veg',hs:'0710',pack:'400 g',
  dEn:'Bottoms or quarters at high-quality standards — ready for frying, sautéing, stuffing or grilling. Also available in brine.',
  dAr:'قلوب أو أرباع بأعلى معايير الجودة — جاهزة للقلي أو التشويح أو الحشو أو الشوي. متوفر أيضًا في محلول ملحي.',
  cuts:[['Bottoms','قلوب'],['Quarters','أرباع']],packs:['400 g','1 kg','2.5 kg','10 kg'],brine:1,season:[1,2,3,4]},
 {id:'strawberry',no:'02',en:'Strawberry',ar:'فراولة',v:'Premium Frozen Strawberries',va:'فراولة مجمدة فاخرة',cat:'fruit',hs:'0811',pack:'400 g',
  dEn:'Frozen at peak ripeness — an excellent source of vitamin C. The go-to input for jams, smoothies, ice cream and bakery.',
  dAr:'مجمدة في ذروة النضج — مصدر ممتاز لفيتامين C. الخيار الأول للمربى والسموذي والآيس كريم والمخبوزات.',
  cuts:[['Whole calibrated','كاملة معايَرة'],['Whole uncalibrated','كاملة غير معايَرة'],['Quarters','أرباع'],['Diced','مكعبات']],packs:['400 g','1 kg','2.5 kg','10 kg'],season:[1,2,3,4,5,6]},
 {id:'mixed-vegetables',no:'03',en:'Mixed Vegetables',ar:'خضار مشكل',v:'Premium Frozen Mixed Vegetables',va:'خضار مشكل مجمد فاخر',cat:'veg',hs:'0710',pack:'400 g',
  dEn:'Green beans, peas and carrots in one balanced blend — a side dish or meal base, ready in minutes.',
  dAr:'فاصوليا خضراء وبسلة وجزر في خلطة متوازنة — طبق جانبي أو أساس وجبة، جاهز في دقائق.',
  cuts:[['Beans + peas + carrots','فاصوليا + بسلة + جزر']],packs:['400 g','1 kg','2.5 kg','10 kg'],season:[1,2,3,4,5,6,7,8,9,10,11,12],all:1},
 {id:'broccoli',no:'04',en:'Broccoli',ar:'بروكلي',v:'Premium Frozen Broccoli Florets',va:'زهرات بروكلي مجمدة',cat:'veg',hs:'0710',pack:'400 g',
  dEn:'Premium florets frozen to preserve nutrients, natural colour and food safety — low in calories, rich in antioxidants.',
  dAr:'زهرات فاخرة مجمدة للحفاظ على العناصر الغذائية واللون الطبيعي وسلامة الغذاء — قليلة السعرات وغنية بمضادات الأكسدة.',
  cuts:[['Florets','زهرات']],packs:['400 g','1 kg','2.5 kg','10 kg'],season:[1,2,12]},
 {id:'molokhia',no:'05',en:'Molokhia',ar:'ملوخية',v:'Premium Frozen Minced Molokhia',va:'ملوخية مفرومة مجمدة',cat:'veg',hs:'0710',pack:'400 g',
  dEn:'The rich oriental taste — farmed and frozen with its vitamins, minerals and natural compounds intact. A staple for Arab-market retail.',
  dAr:'الطعم الشرقي الغني — مزروعة ومجمدة مع الحفاظ على فيتاميناتها ومعادنها. منتج أساسي لأسواق التجزئة العربية.',
  cuts:[['Minced','مفرومة'],['Leaves','ورق']],packs:['400 g'],season:[6,7,8,9]},
 {id:'green-peas',no:'06',en:'Green Peas',ar:'بسلة',v:'Premium Frozen Green Peas',va:'بسلة خضراء مجمدة',cat:'veg',hs:'0710',pack:'400 g',
  dEn:'Picked and frozen with technology that locks in natural sweetness and bite.',
  dAr:'تُقطف وتُجمَّد بتقنية تحفظ حلاوتها الطبيعية وقوامها.',
  cuts:[['Whole','حبوب كاملة']],packs:['400 g','1 kg','2.5 kg','10 kg'],season:[1,2,12]},
 {id:'spinach',no:'07',en:'Spinach',ar:'سبانخ',v:'Premium Frozen Chopped Spinach',va:'سبانخ مفرومة مجمدة',cat:'veg',hs:'0710',pack:'400 g',
  dEn:'High in vitamins K, C and B2 — chopped or whole leaf, frozen at harvest.',
  dAr:'غنية بفيتامينات K وC وB2 — مفرومة أو ورق كامل، مجمدة وقت الحصاد.',
  cuts:[['Chopped','مفرومة'],['Leaves','ورق']],packs:['400 g'],season:[1,11,12]},
 {id:'okra',no:'08',en:'Okra',ar:'بامية',v:'Premium Frozen Okra',va:'بامية مجمدة فاخرة',cat:'veg',hs:'0710',pack:'400 g',
  dEn:'The true flavour of okra any time of year — graded by size from Extra to Two.',
  dAr:'الطعم الحقيقي للبامية في أي وقت من العام — مصنفة بالحجم من إكسترا حتى درجة 2.',
  cuts:[['Extra (0–2.5 cm)','إكسترا (0–2.5 سم)'],['Zero (2.5–3.5 cm)','زيرو (2.5–3.5 سم)'],['One (3.5–4.5 cm)','واحد (3.5–4.5 سم)'],['Two (4.5–5.5 cm)','اثنان (4.5–5.5 سم)']],packs:['400 g','1 kg','2.5 kg','10 kg'],season:[6,7,8,9]},
 {id:'colocasia',no:'09',en:'Colocasia',ar:'قلقاس',v:'Premium Frozen Colocasia',va:'قلقاس مجمد فاخر',cat:'veg',hs:'0710',pack:'400 g',
  dEn:'Cleanly peeled, diced and frozen — a staple of traditional Middle Eastern kitchens.',
  dAr:'مقشر ومقطع ومجمد بعناية — عنصر أساسي في المطبخ الشرقي التقليدي.',
  cuts:[['Diced','مكعبات']],packs:['400 g','1 kg','2.5 kg','10 kg'],season:[1,11,12]},
 {id:'cut-green-beans',no:'10',en:'Cut Green Beans',ar:'فاصوليا خضراء',v:'Premium Frozen Cut Green Beans',va:'فاصوليا خضراء مقطعة مجمدة',cat:'veg',hs:'0710',pack:'400 g',
  dEn:'Consistent cut, ready to steam and cooked in minutes — a satisfying bite every time.',
  dAr:'تقطيع منتظم، جاهزة للطهي على البخار في دقائق — قوام ثابت في كل مرة.',
  cuts:[['Cut','مقطعة'],['Whole','كاملة']],packs:['400 g','1 kg','2.5 kg','10 kg'],season:[5,6,10,11]},
 {id:'broad-beans',no:'11',en:'Broad Beans',ar:'فول أخضر',v:'Premium Frozen Broad Beans',va:'فول أخضر مجمد فاخر',cat:'veg',hs:'0710',pack:'400 g',
  dEn:'A great source of plant protein, fibre and folate — single or double peeled.',
  dAr:'مصدر رائع للبروتين النباتي والألياف والفولات — مقشور مرة أو مرتين.',
  cuts:[['Single peeled','مقشور مرة'],['Double peeled','مقشور مرتين']],packs:['400 g','1 kg','2.5 kg','10 kg'],season:[2,3]},
 {id:'cauliflower',no:'12',en:'Cauliflower',ar:'قرنبيط',v:'Premium Frozen Cauliflower Florets',va:'زهرات قرنبيط مجمدة',cat:'veg',hs:'0710',pack:'400 g',
  dEn:'The flavour, colour and nutrients of fresh cauliflower — with the convenience of frozen.',
  dAr:'نكهة ولون وقيمة القرنبيط الطازج — مع سهولة المنتج المجمد.',
  cuts:[['Florets','زهرات']],packs:['400 g','1 kg','2.5 kg','10 kg'],season:[1,2,12]},
 {id:'pomegranate',no:'13',en:'Pomegranate',ar:'رمان',v:'Premium Frozen Pomegranate Arils',va:'حبوب رمان مجمدة',cat:'fruit',hs:'0811',pack:'400 g',
  dEn:'Sweet, crunchy and juicy IQF arils — ready to use all year. No peeling, no waste.',
  dAr:'حبوب رمان مجمدة حلوة ومقرمشة — جاهزة للاستخدام طوال العام. بلا تقشير ولا هدر.',
  cuts:[['Arils','حبوب']],packs:['400 g','1 kg','2.5 kg','10 kg'],season:[9,10]},
 {id:'french-fries',no:'14',en:'French Fries',ar:'بطاطس فرايز',v:'Premium Frozen Potato Fries',va:'بطاطس فرايز مجمدة',cat:'potato',hs:'2004.10',pack:'2.5 kg',
  dEn:'Straight-cut potato fries, individually quick frozen — a food-service staple for HoReCa and QSR, packed in 2.5 kg bags.',
  dAr:'أصابع بطاطس مقطعة ومجمدة فرديًا — منتج أساسي للفنادق والمطاعم وسلاسل الوجبات السريعة، في عبوات 2.5 كجم.',
  cuts:[['Straight cut','تقطيع مستقيم']],packs:['2.5 kg'],season:null,isNew:1}
];
const EXTRA_SEASON=[];
const MONTHS_EN=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const MONTHS_AR=['ينا','فبر','مار','أبر','ماي','يون','يول','أغس','سبت','أكت','نوف','ديس'];
const EXPOS=[['GULFOOD','Dubai'],['SIAL','Paris'],['ANUGA','Cologne'],['SIAL','Montreal'],['WORLD FOOD','Moscow'],['CHINA INTERNATIONAL','China']];
const COUNTRIES=['Egypt','Saudi Arabia','UAE','Kuwait','Qatar','Bahrain','Oman','Jordan','Lebanon','Palestine','Libya','Tunisia','Algeria','Morocco','Sudan','Turkey','USA','Canada','Mexico','Brazil','Argentina','Uruguay','Peru','United Kingdom','France','Germany','Netherlands','Belgium','Spain','Portugal','Italy','Greece','Cyprus','Austria','Switzerland','Sweden','Denmark','Poland','Czech Republic','Slovakia','Slovenia','Hungary','Serbia','Albania','Russia','China','Japan','Taiwan','Thailand','Vietnam','Sri Lanka','Australia','Other'];
/* dot-matrix world map derived from the original Frosty export map: 0 sea · 1 land · 2 export market */
const MAP={"rows":["0000000000000000000000000000000000000000001122222211111111111110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000","0000000000000000000000000000000000000002222222211111111111111110000000000111100000000000000000000012010000000000000000000000000000000000000000000000000000000000","0000000000000000000000000000011010010111222100111111111111111110000000000110000000000000000000000000002100000000000000000000000000000000000000000000000000000000","0000000000000000000000000011012110112122200000000111111111111100000000000000000000000000210000000012222222200000000111000000000000000000000000000000000000000000","0000000000000000000000000222221202221222220000000111111111111000000000000000000000000002000002001222222222222222220000210000000000000000000000000000000000000000","0000000000122210000000100022222101200222222100000111111111111000000000000000111100000000100002222222222222222222222222222222220000001000000000000000000000000000","0000000222222222222222222212222122221200122200000111111111100000000000000012211222200112222222222222222222222222222222222222222222222221000000000000000000000000","0000011222222222222222122222222222222000122220001111111000000110000000000122211222122222222222222222222222222222222222222222222222222222222200000000000000000000","0000022222222222222222222222222222221011222000001111100000011110000000001222111122222222222222222222222222222222222222222222222222222222200100000000000000000000","0002222222222222222222222222222200000110011000001111000000000000000000111220111122222222222222222222222222222222222222222222222222222222220000000000000000000000","0022222221222222222222222222220000000222000000000110000000000000000000111221011222222222222222222222222222222222222222222222222222100222200000000000000000000000","0012210000002222222222222222220000002222121000000000000000000000001000111220011222222222222222222222222222222222222222222222220000000210000000000000000000000000","0110000000002222222222222222222000002222221000000000000000000000022000011220011122222222222222222222222222222222222222222222210000000221000000000000000000000000","0000000000001222222222222222222220122222222000000000000000000000122100011001111112222222222222221122222222222222222222222222210000000122000000000000000000000000","0000000000001222222222222122222220222222222200000000000000000001102200222222221112222222222222111111122222222222222222222222222220000012000000000000000000000000","0000000000002222222222222222222222222222221100000000000000000000002212222222221111122222211222111111111222222211222222222222222221000001000000000000000000000000","0000000000002222222222222222222222222220002200000000000000000000000222222222221111111222111111111111111111211111111111122222222221200000000000000000000000000000","0000000000002222222222222221002222222220001200000000000000000000002222222222221111111222211111111111111112221111111111111222222222000000000000000000000000000000","0000000000002222222222222222221222222222000000000000000000000000000222222211211110111222200111111111111122222111111111112222222221000000000000000000000000000000","0000000000022222222222222222222212220000000000000000000000000000101222212111221110000122200111111111111122222221111111222222222220002200000000000000000000000000","0000000000222222222222222222222222200000000000000000000000000002222220000210211110110011120011111111000022222222222122222222222100001000000000000000000000000000","0000000000222222222222222222222220000000000000000000000000000002222200020021121122222222111011111111102222222222222222222221211000002000000000000000000000000000","0000000000222222222222222222222210000000000000000000000000000002222000000000021022222222111011111111112222222222222222222220001100001200000000000000000000000000","0000000000222222222222222222222100000000000000000000000000000000220012220000010012222111111111111111111222222222222222222222200110002200000000000000000000000000","0000000000222222222222222222222000000000000000000000000000000000222222221000000000001111111111111111111112222222222222222222000110222100000000000000000000000000","0000000000022222222222222222210000000000000000000000000000000002222222222000000000001111111111111111111112222222222222222222200001200000000000000000000000000000","0000000000022222222222222222000000000000000000000000000000000012222222222221022110112221111111111111111112222222222222222222220000100000000000000000000000000000","0000000000021222222222220012000000000000000000000000000000000022222222222222222111112222211111111111111111112222222222222222220000000000000000000000000000000000","0000000000011222222200000002000000000000000000000000000000000122222222222222222111112222222011111111111111111121111222222222220000000000000000000000000000000000","0000000000002022222200000002000000000000000000000000000000001111222222222222222111110222222200011111111111111111111222222222220000000000000000000000000000000000","0000000000001022222000000000000000000000000000000000000000011111122222222222222111111022222221200000111111111110111222222222202000000000000000000000000000000000","0000000000000002222000000011000000000000000000000000000000011111111222221111222211112022222222221000011111111110011122222222001000000000000000000000000000000000","0000000000000002222000120000110000000000000000000000000000011111111122211111112222222202222222220000001111111100011111220100000000000000000000000000000000000000","0000000000000002222200220000000100000000000000000000000000011111111111111111111222222201222222210000000111111000001121120100000000000000000000000000000000000000","0000000000000000022222000000000000000000000000000000000000011111111111111111111222222210222112100000000111110000001122211000000100000000000000000000000000000000","0000000000000000000011011000000000000000000000000000000000011111111111111111111222222110111110000000000011100000000022221000000100000000000000000000000000000000","0000000000000000000000011100000000000000000000000000000000011111111111111111112222222111111000000000000011100000000022211200000110000000000000000000000000000000","0000000000000000000000011000000000000000000000000000000000000111111111111111112222222111100000000000000001100000000010111200000001000000000000000000000000000000","0000000000000000000000001100011111110000000000000000000000000001111101111111111222111111111110000000000001100000000010012000000011000000000000000000000000000000","0000000000000000000000000111111111111000000000000000000000000001111111111111111111111111111100000000000000020000000011000000000001100000000000000000000000000000","0000000000000000000000000000111111111100000000000000000000000001111111111111111111111111111100000000000000020000000001000000000001100000000000000000000000000000","0000000000000000000000000000111111111111000000000000000000000001111000111111111111111111111100000000000000000000000101100000011000000000000000000000000000000000","0000000000000000000000000000111111122111110000000000000000000000000000001111111111111111111000000000000000000000000011100000110000000000000000000000000000000000","0000000000000000000000000001111121122222220000000000000000000000000000001111111111111111110000000000000000000000000011110011111000010000000000000000000000000000","0000000000000000000000000011111122222222221000000000000000000000000000001111111111101111100000000000000000000000000001110011110000000100000000000000000000000000","0000000000000000000000000011111122222222222220000000000000000000000000001111111111111111000000000000000000000000000000111011110110000110110000000000000000000000","0000000000000000000000000011111122222222222222220000000000000000000000001111111111111110000000000000000000000000000000111000000110000011111100000000000000000000","0000000000000000000000000011112222222222222222222100000000000000000000000111111111111110000000000000000000000000000000011000000000000000111110110000000000000000","0000000000000000000000000001112222222222222222222200000000000000000000000111111111111110000000000000000000000000000000000111000000000000111110000000000000000000","0000000000000000000000000001112222222222222222222100000000000000000000000011111111111110000000000000000000000000000000000000000101100000001001000000000000000000","0000000000000000000000000000111121222222222222222000000000000000000000000011111111111111000000000000000000000000000000000000000000000000000000000000000000000000","0000000000000000000000000000011111122222222222220000000000000000000000000111111111111111000100000000000000000000000000000000000000002221002000000000000000000000","0000000000000000000000000000011111111222222222220000000000000000000000000111111111110111000100000000000000000000000000000000000000212220002000000000000000000000","0000000000000000000000000000001111111122222222220000000000000000000000000111111111111110011100000000000000000000000000000000000002222222012200000000000000000000","0000000000000000000000000000000011111122222222220000000000000000000000000111111111111100011100000000000000000000000000000000000022222222222200000000000000000000","0000000000000000000000000000000011111122222222210000000000000000000000000111111111111000011100000000000000000000000000000000000222222222222210000000000000000000","0000000000000000000000000000000011111112222222200000000000000000000000000011111111111000011000000000000000000000000000000000222222222222222220000000000000000000","0000000000000000000000000000000011222111222221000000000000000000000000000011111111111000111000000000000000000000000000000002222222222222222221000000000000000000","0000000000000000000000000000000011222221222200000000000000000000000000000011111111110000010000000000000000000000000000000002222222222222222222000000000000000000","0000000000000000000000000000000011222221222100000000000000000000000000000011111111100000000000000000000000000000000000000002222222222222222222000000000000000000","0000000000000000000000000000000012222222222100000000000000000000000000000001111111100000000000000000000000000000000000000002222222222222222222000000000000000000","0000000000000000000000000000000012222222222000000000000000000000000000000001111111000000000000000000000000000000000000000002222222222222222221000000000000000000","0000000000000000000000000000000002222222221000000000000000000000000000000000111110000000000000000000000000000000000000000002222220022222222220000000000000000000","0000000000000000000000000000000001222222220000000000000000000000000000000000111100000000000000000000000000000000000000000022211000002222222200000000000000000000","0000000000000000000000000000000001222222000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000222222000000000010000000000","0000000000000000000000000000000001222222100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000222220000000000011000000000","0000000000000000000000000000000001222220000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011000000000","0000000000000000000000000000000001222210000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001100000000000","0000000000000000000000000000000000222200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000110000000000000","0000000000000000000000000000000000122200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011100000000000000","0000000000000000000000000000000000122200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000","0000000000000000000000000000000000112200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000","0000000000000000000000000000000000022200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000","0000000000000000000000000000000000011200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000","0000000000000000000000000000000000001110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000","0000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"]};
const NOW_M=new Date().getMonth()+1;

/* ================= LANG ================= */
let LANG=(()=>{try{return localStorage.getItem('frosty-lang')||'en'}catch(e){return 'en'}})();
const FROSTY_URL=window.FROSTY_URL||(u=>u);
const T=(en,ar)=>{if(window.CMS_UIREG&&!/\d/.test(en))CMS_UIREG[en]=ar;const o=window.CMS_UI&&CMS_UI[en];if(o)return LANG==='ar'?(o.ar||ar):(o.en||en);return LANG==='ar'?ar:en};
function applyLang(l){
  LANG=l;try{localStorage.setItem('frosty-lang',l)}catch(e){}
  const h=document.documentElement;h.lang=l;h.dir=l==='ar'?'rtl':'ltr';
  document.querySelectorAll('[data-ar]').forEach(el=>{
    if(el.dataset.en===undefined)el.dataset.en=el.innerHTML;
    el.innerHTML=l==='ar'?el.dataset.ar:el.dataset.en;
  });
  document.querySelectorAll('[data-ph-ar]').forEach(el=>{
    if(el.dataset.phEn===undefined)el.dataset.phEn=el.placeholder;
    el.placeholder=l==='ar'?el.dataset.phAr:el.dataset.phEn;
  });
  document.getElementById('lEn').classList.toggle('on',l==='en');
  document.getElementById('lAr').classList.toggle('on',l==='ar');
  const S=window.CMS_SEO||{};document.title=(l==='ar'?S.titleAr:S.titleEn)||(l==='ar'?'فروستي فودز — خضروات وفواكه مجمدة IQF من مصر إلى العالم':'Frosty Foods — IQF Fruits & Vegetables from Egypt to the World');
  const md=document.getElementById('metaDesc');if(md&&(S.descEn||S.descAr))md.content=(l==='ar'?S.descAr:S.descEn)||S.descEn||'';
  renderSeason();renderGrid();renderCal();renderRegions();renderFaq();setStepText();renderChips();renderFooter();renderCountries();renderMarquee();
  if(openId)openModal(openId);
}
document.getElementById('lEn').onclick=()=>applyLang('en');
document.getElementById('lAr').onclick=()=>applyLang('ar');

/* ================= NAV ================= */
const nav=document.getElementById('nav');
const onScroll=()=>{nav.classList.toggle('solid',scrollY>40)};
addEventListener('scroll',onScroll,{passive:true});onScroll();
const burger=document.getElementById('burger'),mm=document.getElementById('mmenu');
burger.onclick=()=>{const o=mm.classList.toggle('open');burger.classList.toggle('x',o);burger.setAttribute('aria-expanded',o);document.body.style.overflow=o?'hidden':'';nav.classList.toggle('solid',o||scrollY>40)};
mm.querySelectorAll('a').forEach(a=>a.onclick=()=>{mm.classList.remove('open');burger.classList.remove('x');document.body.style.overflow=''});
const secs=[...document.querySelectorAll('section[id]')],links=[...document.querySelectorAll('.nav-links a')];
const navIO=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)links.forEach(a=>a.classList.toggle('act',a.getAttribute('href')==='#'+e.target.id))}),{rootMargin:'-45% 0px -50% 0px'});
secs.forEach(s=>navIO.observe(s));

/* ================= REVEAL + COUNTERS ================= */
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}}),{threshold:.12,rootMargin:'0px 0px -6% 0px'});
const observeRv=root=>(root||document).querySelectorAll('.rv:not(.in)').forEach(el=>io.observe(el));
observeRv();
function countUp(el){const to=+el.dataset.to,d=1600,t0=performance.now();const f=t=>{const p=Math.min((t-t0)/d,1);el.textContent=Math.round(to*(1-Math.pow(1-p,3)));if(p<1)requestAnimationFrame(f)};requestAnimationFrame(f)}
setTimeout(()=>document.querySelectorAll('.count').forEach(countUp),900);

/* ================= SEASON TICKER ================= */
function renderSeason(){
  const list=[...P.filter(p=>p.season&&!p.all&&p.season.includes(NOW_M)).map(p=>T(p.en,p.ar)),...EXTRA_SEASON.filter(s=>s.season.includes(NOW_M)).map(s=>T(s.en,s.ar))];
  const M=(LANG==='ar'?['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر']:['January','February','March','April','May','June','July','August','September','October','November','December'])[NOW_M-1];
  document.getElementById('seasonLabel').textContent=T('In season · '+M,'في الموسم · '+M);
  document.getElementById('seasonText').innerHTML=list.length?`${list.join(' · ')} — <a href="#rfq">${T('book the harvest','احجز المحصول')}</a>`:T('All lines available year-round from frozen stock.','جميع الأصناف متاحة طوال العام من المخزون المجمد.');
}

/* ================= MARQUEE ================= */
function renderMarquee(){
  const set=EXPOS.map(e=>`<span class="mq-item">${e[0]}<small>${e[1]}</small></span>`).join('');
  const lbl=`<span class="mq-item" style="color:var(--ink-50);font-weight:600;font-family:var(--f-body);font-size:.85rem">${T('Exhibiting at','نشارك في')}</span>`;
  document.getElementById('mq').innerHTML=(lbl+set).repeat(2);
}

/* ================= PRODUCTS ================= */
let filter='all',globalFace='front';const basket=new Set();
const img=(id,f)=>{const p=P.find(x=>x.id===id);return FROSTY_URL((p&&p[f])||'assets/img/packs/'+id+'-'+f+'.webp')};
const catLabel=c=>c==='fruit'?T('Fruit','فاكهة'):c==='potato'?T('Potato','بطاطس'):T('Vegetable','خضار');
const inSeason=p=>p.season&&!p.all&&p.season.includes(NOW_M);
function cardHTML(p){
  const back=globalFace==='back';
  return `<article class="pc rv ${back?'back':''} ${filter==='all'||p.cat===filter?'':'hide'}" data-id="${p.id}">
    <div class="pc-stage" role="button" tabindex="0" aria-label="${T('Open spec sheet','افتح بطاقة المواصفات')}: ${T(p.en,p.ar)}">
      <div class="pc-top"><span class="pc-no">${p.no}</span><span class="pc-face-tag">${back?T('Back','الخلف'):T('Front','الأمام')}</span></div>
      <div class="pc-flip"><div class="pc-face"><img src="${img(p.id,'front')}" alt="${p.en} — front of pack" loading="lazy"></div><div class="pc-face b"><img src="${img(p.id,'back')}" alt="${p.en} — back of pack" loading="lazy"></div></div>
    </div>
    <div class="pc-body">
      <div class="pc-name"><h3>${LANG==='ar'?p.ar:p.en}</h3><span>${LANG==='ar'?p.en:p.ar}</span></div>
      <div class="pc-meta"><span>${p.pack}</span>${inSeason(p)?`<span class="s">${T('In season','في الموسم')}</span>`:''}${p.isNew?`<span class="s">${T('New','جديد')}</span>`:''}<span>${catLabel(p.cat)}</span></div>
      <div class="pc-act">
        <div class="seg"><button class="${back?'':'on'}" data-f="front">${T('Front','الأمام')}</button><button class="${back?'on':''}" data-f="back">${T('Back','الخلف')}</button></div>
        <button class="add ${basket.has(p.id)?'on':''}" data-add="${p.id}" aria-pressed="${basket.has(p.id)}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M12 5v14M5 12h14"/></svg>${T('Quote','عرض سعر')}</button>
      </div>
    </div>
  </article>`;
}
function ctaCards(){
  const hide=filter==='all'?'':'hide';
  return `<article class="pc pc-cta rv ${hide}"><div><span class="mono">${T('Private label','علامة خاصة')}</span><h3>${T('Your brand. Our certified lines.','علامتك التجارية. خطوطنا المعتمدة.')}</h3><p>${T('Any line in the range, packed under your artwork and specifications.','أي صنف من التشكيلة، معبأ بتصميمك ومواصفاتك.')}</p><ul><li>400 g · 1 kg · 2.5 kg · 10 kg</li><li>${T('Bilingual artwork support','دعم التصميم ثنائي اللغة')}</li><li>BRC · ISO 22000 · FSSC 22000</li></ul></div><a href="#rfq" class="btn btn-primary" data-pl="1">${T('Start a project','ابدأ مشروع علامة خاصة')}<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a></article>
  <article class="pc pc-cta alt rv ${hide}"><div><span class="mono">${T('Food service & bulk','الجملة وخدمات الطعام')}</span><h3>${T('Catering and bulk formats.','صيغ للجملة والمطابخ المركزية.')}</h3><p>${T('The same IQF quality in formats built for kitchens and processors.','نفس جودة IQF بصيغ مصممة للمطابخ والمصانع.')}</p><ul><li>4 × 2.5 kg · 1 × 10 kg</li><li>${T('Brine & syrup drums — 225 kg','براميل محلول ملحي وشراب — 225 كجم')}</li><li>${T('Mixed-product containers','حاويات مشكّلة من عدة أصناف')}</li></ul></div><a href="#logistics" class="btn btn-line">${T('See packing specs','مواصفات التعبئة')}<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a></article>`;
}
function renderGrid(){
  const g=document.getElementById('pGrid');
  g.innerHTML=P.map(cardHTML).join('')+ctaCards();
  g.querySelectorAll('.pc').forEach(c=>c.classList.add('in'));
  document.querySelectorAll('#tabs .tab').forEach(t=>{const f=t.dataset.f,s=t.querySelector('small');if(s)s.textContent=f==='all'?P.length:P.filter(p=>p.cat===f).length});
}
const pGrid=document.getElementById('pGrid');
pGrid.addEventListener('click',e=>{
  const card=e.target.closest('.pc[data-id]');
  const pl=e.target.closest('[data-pl]');if(pl){const t=document.getElementById('fType');t.value='Private label';}
  if(!card)return;
  const fb=e.target.closest('.seg button');
  if(fb){const back=fb.dataset.f==='back';card.classList.toggle('back',back);fb.parentElement.querySelectorAll('button').forEach(b=>b.classList.toggle('on',b===fb));card.querySelector('.pc-face-tag').textContent=back?T('Back','الخلف'):T('Front','الأمام');return}
  const ad=e.target.closest('[data-add]');if(ad){toggleBasket(card.dataset.id);return}
  if(e.target.closest('.pc-stage'))openModal(card.dataset.id);
});
pGrid.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target.classList.contains('pc-stage')){e.preventDefault();openModal(e.target.closest('.pc').dataset.id)}});
document.getElementById('tabs').addEventListener('click',e=>{const b=e.target.closest('.tab');if(!b)return;document.querySelectorAll('.tab').forEach(t=>t.classList.toggle('on',t===b));filter=b.dataset.f;
  pGrid.querySelectorAll('.pc[data-id]').forEach(c=>{const p=P.find(x=>x.id===c.dataset.id);c.classList.toggle('hide',!(filter==='all'||p.cat===filter))});
  pGrid.querySelectorAll('.pc-cta').forEach(c=>c.classList.toggle('hide',filter!=='all'))});
document.getElementById('globalFace').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;globalFace=b.dataset.face;
  document.querySelectorAll('#globalFace button').forEach(x=>x.classList.toggle('on',x===b));
  pGrid.querySelectorAll('.pc[data-id]').forEach((c,i)=>setTimeout(()=>{const back=globalFace==='back';c.classList.toggle('back',back);c.querySelectorAll('.seg button').forEach(s=>s.classList.toggle('on',(s.dataset.f==='back')===back));c.querySelector('.pc-face-tag').textContent=back?T('Back','الخلف'):T('Front','الأمام')},i*45))});

/* basket <-> RFQ chips */
function toggleBasket(id,force){
  const on=force!==undefined?force:!basket.has(id);on?basket.add(id):basket.delete(id);
  document.querySelectorAll(`[data-add="${id}"]`).forEach(b=>{b.classList.toggle('on',on);b.setAttribute('aria-pressed',on)});
  document.querySelectorAll(`.chip[data-id="${id}"]`).forEach(c=>{c.classList.toggle('on',on);c.setAttribute('aria-checked',on)});
  const cnt=document.getElementById('basketCnt');cnt.textContent=basket.size;cnt.classList.toggle('on',basket.size>0);
  if(openId===id)setModalAdd();
}
function renderChips(){
  const box=document.getElementById('chips');
  box.innerHTML=P.map(p=>`<span class="chip ${basket.has(p.id)?'on':''}" data-id="${p.id}" role="checkbox" tabindex="0" aria-checked="${basket.has(p.id)}">${T(p.en,p.ar)}</span>`).join('');
}
document.getElementById('chips').addEventListener('click',e=>{const c=e.target.closest('.chip');if(c){toggleBasket(c.dataset.id);document.getElementById('chips').classList.remove('err')}});
document.getElementById('chips').addEventListener('keydown',e=>{const c=e.target.closest('.chip');if(c&&(e.key==='Enter'||e.key===' ')){e.preventDefault();toggleBasket(c.dataset.id)}});

/* ================= MODAL ================= */
const modal=document.getElementById('modal');let openId=null;
function setModalAdd(){const on=basket.has(openId);document.getElementById('mAdd').innerHTML=on?T('✓ Added to quotation','✓ أضيف لطلب السعر'):T('+ Add to quotation','+ أضف لطلب السعر')}
function openModal(id){
  const p=P.find(x=>x.id===id);if(!p)return;openId=id;
  const f=document.getElementById('mFront'),b=document.getElementById('mBack');
  f.src=img(id,'front');b.src=img(id,'back');f.alt=p.en+' front';b.alt=p.en+' back';
  document.getElementById('mNo').textContent=`SKU ${p.no} · ${catLabel(p.cat)}`;
  document.getElementById('mName').textContent=LANG==='ar'?p.ar:p.en;
  document.getElementById('mAr').textContent=LANG==='ar'?p.en:p.ar;
  document.getElementById('mDesc').textContent=T(p.dEn,p.dAr);
  const M=LANG==='ar'?MONTHS_AR:MONTHS_EN;
  const season=p.season?`<div class="months">${M.map((m,i)=>`<i class="${p.season.includes(i+1)?'on':''}">${m}</i>`).join('')}</div>`:T('Supplied year-round from frozen stock','يورَّد طوال العام من المخزون المجمد');
  const rows=[
    [T('Product','المنتج'),T(p.v,p.va)],
    [T('Retail pack','عبوة التجزئة'),`<span class="tag" dir="ltr">${p.pack}</span>`],
    [T('Cuts & grades','التقطيعات والدرجات'),p.cuts.map(c=>`<span class="tag">${T(c[0],c[1])}</span>`).join('')],
    [T('Available formats','الصيغ المتاحة'),p.packs.map(k=>`<span class="tag" dir="ltr">${k}</span>`).join('')+(p.brine?`<span class="tag">${T('Brine drums 225 kg','براميل محلول ملحي 225 كجم')}</span>`:'')+`<span class="tag">${T('Private label','علامة خاصة')}</span>`],
    [T('Harvest window','نافذة الحصاد'),p.all?T('Year-round blend','خلطة متاحة طوال العام'):season],
    [T('Storage','التخزين'),`<span dir="ltr">≤ −18°C</span> · ${T('IQF, free-flowing','IQF، قطع منفصلة')}`],
    [T('HS heading','البند الجمركي'),`<span dir="ltr">${p.hs}</span>`],
    [T('Certification','الشهادات'),'BRC · ISO 22000 · FSSC 22000 · FDA · KLBD']
  ];
  document.getElementById('mSheet').innerHTML=rows.map(r=>`<tr><th>${r[0]}</th><td>${r[1]}</td></tr>`).join('');
  setModalAdd();
  modal.classList.add('open');document.body.style.overflow='hidden';
}
function closeModal(){modal.classList.remove('open');document.body.style.overflow='';openId=null}
document.getElementById('mClose').onclick=closeModal;
modal.addEventListener('click',e=>{if(e.target===modal)closeModal()});
document.getElementById('mAdd').onclick=()=>toggleBasket(openId);
document.getElementById('mGo').onclick=()=>{if(openId)toggleBasket(openId,true);closeModal()};
const lb=document.getElementById('lightbox');
document.querySelectorAll('.m-view').forEach(v=>v.onclick=()=>{document.getElementById('lbImg').src=v.querySelector('img').src;lb.classList.add('open')});
lb.onclick=()=>lb.classList.remove('open');
addEventListener('keydown',e=>{if(e.key==='Escape'){if(lb.classList.contains('open'))lb.classList.remove('open');else if(openId)closeModal()}});

/* ================= HARVEST PLANNER ================= */
let selM=NOW_M;
const MONTHS_FULL_EN=['January','February','March','April','May','June','July','August','September','October','November','December'];
const MONTHS_FULL_AR=['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
const SEASONAL=()=>[...P.filter(p=>p.season&&!p.all),...EXTRA_SEASON];
function windows(s){const M=LANG==='ar'?MONTHS_AR:MONTHS_EN;const out=[];for(let m=1;m<=12;m++){const prev=m===1?12:m-1;if(s.includes(m)&&!s.includes(prev)){let e=m;while(s.includes(e===12?1:e+1)&&(e===12?1:e+1)!==m)e=e===12?1:e+1;out.push(e===m?M[m-1]:M[m-1]+' – '+M[e-1])}}return out.join(', ')}
function renderCal(){
  const M=LANG==='ar'?MONTHS_AR:MONTHS_EN,list=SEASONAL();
  document.getElementById('monthsBar').innerHTML=M.map((m,i)=>{const n=list.filter(p=>p.season.includes(i+1)).length;return `<button class="mbtn ${i+1===NOW_M?'now':''} ${i+1===selM?'on':''}" data-m="${i+1}" role="tab" aria-selected="${i+1===selM}">${m}<span class="pips">${'<i></i>'.repeat(Math.min(n,5))}</span></button>`}).join('');
  const full=(LANG==='ar'?MONTHS_FULL_AR:MONTHS_FULL_EN)[selM-1];
  const now=list.filter(p=>p.season.includes(selM));
  const rows=now.map((p,i)=>`<div class="crop" style="animation-delay:${(i*.05).toFixed(2)}s">${p.id?`<img src="${img(p.id,'front')}" alt="" loading="lazy">`:`<span class="ph">${T('FRUIT','فاكهة')}</span>`}<div><b>${T(p.en,p.ar)}</b><small>${T('Window','الموسم')}: ${windows(p.season)}</small></div><div class="mini">${[...Array(12)].map((_,k)=>`<i class="${p.season.includes(k+1)?'on':''} ${k+1===selM?'sel':''}"></i>`).join('')}</div></div>`).join('');
  const nxt=[1,2,3].map(d=>{const m=(selM-1+d)%12+1;const s=list.filter(p=>p.season.includes(m)&&!p.season.includes(m===1?12:m-1));return s.length?`<span class="mono">${M[m-1]}</span>${s.map(p=>`<em>${T(p.en,p.ar)}</em>`).join('')}`:''}).join('');
  document.getElementById('plBody').innerHTML=`<div class="pl-head"><b>${T('Harvesting in '+full,'الحصاد في '+full)}</b><span>${now.length} ${T(now.length===1?'crop':'crops','محاصيل')}${selM===NOW_M?' · '+T('this month','الشهر الحالي'):''}</span></div><div class="crops">${rows||`<div class="pl-empty">${T('No fresh harvest this month — all lines supplied from frozen stock.','لا يوجد حصاد طازج هذا الشهر — كل الأصناف تورَّد من المخزون المجمد.')}</div>`}</div>${nxt?`<div class="pl-next"><span>${T('Opening next:','يبدأ قريبًا:')}</span>${nxt}</div>`:''}`;
}
document.getElementById('monthsBar').addEventListener('click',e=>{const b=e.target.closest('.mbtn');if(b){selM=+b.dataset.m;renderCal()}});

/* ================= COUNTRIES / FOOTER ================= */
function renderCountries(){const s=document.getElementById('fCountry'),v=s.value;s.innerHTML=`<option value="">${T('Select country…','اختر الدولة…')}</option>`+COUNTRIES.map(c=>`<option>${c}</option>`).join('');s.value=v}
function renderFooter(){document.getElementById('fProds').innerHTML=P.slice(0,8).map(p=>`<li><a href="#products" data-open="${p.id}">${T(p.en,p.ar)}</a></li>`).join('')+`<li><a href="#products">${T('View all 14 →','عرض الـ 14 منتج ←')}</a></li>`}
document.getElementById('fProds').addEventListener('click',e=>{const a=e.target.closest('[data-open]');if(a){e.preventDefault();openModal(a.dataset.open)}});
document.getElementById('yr').textContent=new Date().getFullYear();

/* ================= IQF PIECES ================= */
(function(){
  const good=document.getElementById('pGood'),bad=document.getElementById('pBad');let g='',b='';
  for(let r=0;r<5;r++)for(let c=0;c<5;c++){
    g+=`<i style="left:${8+c*18+(r%2?4:0)}%;top:${8+r*18}%;animation-delay:${((r*5+c)*.13).toFixed(2)}s"></i>`;
    if(r>0&&r<4&&c>0&&c<4)b+=`<i style="left:${24+(c-1)*18}%;top:${24+(r-1)*18}%"></i>`;
  }
  good.innerHTML=g;bad.innerHTML=b;
})();

/* ================= PROCESS PROGRESS + PARALLAX ================= */
const proc=document.getElementById('process'),pf=document.getElementById('processFill'),steps=[...proc.querySelectorAll('.pstep')];
const prodBg=document.getElementById('prodBg'),facImg=document.getElementById('facImg');
const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
let ticking=false;
function frame(){
  ticking=false;const vh=innerHeight;
  const r=proc.getBoundingClientRect();
  const p=Math.max(0,Math.min(1,(vh*.78-r.top)/(r.height+vh*.35)));
  pf.style.setProperty('--p',p.toFixed(3));
  steps.forEach((s,i)=>s.classList.toggle('on',p>=i/(steps.length-1)-.02));
  if(!reduce){
    const pr=prodBg.parentElement.getBoundingClientRect();
    if(pr.bottom>0&&pr.top<vh)prodBg.style.transform=`translateY(${((pr.top+pr.height/2-vh/2)*-.12).toFixed(1)}px)`;
    const fr=facImg.getBoundingClientRect();
    if(fr.bottom>0&&fr.top<vh)facImg.style.transform=`translateY(${((fr.top+fr.height/2-vh/2)*-.08).toFixed(1)}px)`;
  }
}
addEventListener('scroll',()=>{if(!ticking){ticking=true;requestAnimationFrame(frame)}},{passive:true});frame();

/* ================= WORLD MAP ================= */
const REGIONS=[
 {k:'na',en:'North America',ar:'أمريكا الشمالية',c:['USA','Canada','Mexico'],ca:['الولايات المتحدة','كندا','المكسيك'],h:[0,1,2]},
 {k:'eu',en:'Europe',ar:'أوروبا',c:['UK','France','Germany','Netherlands','Belgium','Spain','Portugal','Italy','Poland','Russia'],ca:['المملكة المتحدة','فرنسا','ألمانيا','هولندا','بلجيكا','إسبانيا','البرتغال','إيطاليا','بولندا','روسيا'],h:[4,5,6]},
 {k:'me',en:'MENA & GCC',ar:'الشرق الأوسط وأفريقيا',c:['Saudi Arabia','Oman','Turkey','Morocco','Algeria','Libya','Sudan'],ca:['السعودية','عُمان','تركيا','المغرب','الجزائر','ليبيا','السودان'],h:[9,10,12]},
 {k:'ap',en:'Asia-Pacific',ar:'آسيا والمحيط الهادئ',c:['China','Japan','Thailand','Sri Lanka','Australia'],ca:['الصين','اليابان','تايلاند','سريلانكا','أستراليا'],h:[7,8,11]},
 {k:'la',en:'Latin America',ar:'أمريكا اللاتينية',c:['Brazil','Argentina','Uruguay'],ca:['البرازيل','الأرجنتين','أوروغواي'],h:[3]}
];
let selR=null;
function renderRegions(){
  document.getElementById('rgList').innerHTML=`<button class="rg ${selR===null?'on':''}" data-r="">${T('All regions','كل المناطق')}<small>50+</small></button>`+REGIONS.map(r=>`<button class="rg ${selR===r.k?'on':''}" data-r="${r.k}">${T(r.en,r.ar)}<small>${String(r.c.length).padStart(2,'0')}</small></button>`).join('');
  const r=REGIONS.find(x=>x.k===selR);
  document.getElementById('rgCountries').textContent=r?(LANG==='ar'?r.ca:r.c).join(' · '):T('Select a region to see key markets. Our full list covers 50+ countries.','اختر منطقة لعرض أهم الأسواق. قائمتنا الكاملة تغطي أكثر من 50 دولة.');
  const box=document.getElementById('mapBox');box.classList.toggle('filter',!!r);
  box.querySelectorAll('[data-h]').forEach(el=>el.classList.toggle('hl',!!r&&r.h.includes(+el.dataset.h)));
}
document.getElementById('rgList').addEventListener('click',e=>{const b=e.target.closest('.rg');if(b){selR=b.dataset.r||null;renderRegions()}});
(function(){
  const svg=document.getElementById('map');if(!MAP)return;
  let land='',mk='';
  MAP.rows.forEach((row,y)=>{for(let x=0;x<row.length;x++){const c=row[x];if(c==='0')continue;const s=`M${x+.5} ${y+.5}h0`;c==='2'?mk+=s:land+=s}});
  const O=[81.8,26.2];
  const hubs=[[36,17],[33.6,21.9],[15.6,29.7],[43.7,46.9],[66.4,14],[72,15.3],[85,12.5],[115.6,23.4],[134,20.3],[89,30.5],[94.5,31.2],[132.8,59.4],[65.6,25]];
  const arcs=hubs.map(([x,y],i)=>{const mx=(O[0]+x)/2,my=(O[1]+y)/2-Math.hypot(x-O[0],y-O[1])*.28;return `<path class="arc" data-h="${i}" pathLength="1" d="M${O[0]} ${O[1]}Q${mx.toFixed(1)} ${my.toFixed(1)} ${x} ${y}" style="animation-delay:${(.3+i*.12).toFixed(2)}s"/><circle class="hub" data-h="${i}" cx="${x}" cy="${y}" r=".5" style="transition-delay:${(1.2+i*.12).toFixed(2)}s"/>`}).join('');
  svg.innerHTML=`<defs><linearGradient id="arcg" x1="0" x2="1"><stop offset="0" stop-color="#3FBE23"/><stop offset="1" stop-color="#8FD6F0"/></linearGradient></defs>
    <path class="dots-land" d="${land}" stroke-width=".52" stroke-linecap="round"/>
    <path class="dots-mk" d="${mk}" stroke-width=".58" stroke-linecap="round"/>
    ${arcs}
    <circle class="origin-ring" cx="${O[0]}" cy="${O[1]}" r="1"/><circle class="origin-ring" cx="${O[0]}" cy="${O[1]}" r="1" style="animation-delay:1.3s"/>
    <circle cx="${O[0]}" cy="${O[1]}" r=".75" fill="#3FBE23" stroke="#fff" stroke-width=".25"/>`;
  const lab=document.getElementById('mapLabel'),box=document.getElementById('mapBox');
  const place=()=>{const sr=svg.getBoundingClientRect(),br=box.getBoundingClientRect();lab.style.left=(sr.left-br.left+O[0]/160*sr.width)+'px';lab.style.top=(sr.top-br.top+O[1]/76*sr.height)+'px'};
  place();addEventListener('resize',place);
  new IntersectionObserver((es,o)=>es.forEach(e=>{if(e.isIntersecting){box.classList.add('in');place();o.disconnect()}}),{threshold:.3}).observe(svg);
})();

/* ================= RFQ STEPS ================= */
let curStep=1;
const STEP1=['fName','fCompany','fEmail','fCountry','fType'];
function checkStep1(){let ok=true;STEP1.forEach(id=>{const el=document.getElementById(id),bad=!el.value.trim()||(el.type==='email'&&!/^\S+@\S+\.\S+$/.test(el.value));el.parentElement.classList.toggle('err',bad);if(bad)ok=false});return ok}
function setStepText(){document.getElementById('stepLbl').textContent=T('Step '+curStep+' of 2','الخطوة '+curStep+' من 2')}
function goStep(n){
  curStep=n;const form=document.getElementById('rfqForm');
  form.querySelectorAll('.fstep').forEach(s=>s.classList.toggle('on',+s.dataset.step===n));
  document.querySelectorAll('#stepper li').forEach(li=>{const s=+li.dataset.s;li.classList.toggle('on',s===n);li.classList.toggle('done',s<n)});
  document.getElementById('toast').className='toast';setStepText();
  const top=form.getBoundingClientRect().top;if(top<80)scrollBy({top:top-110,behavior:'smooth'});
  const f=form.querySelector('.fstep.on :is(input,select,.chip)');if(f&&n===2&&!basket.size)f.focus({preventScroll:true});
}
function step1Fail(){const t=document.getElementById('toast');t.className='toast show bad';t.textContent=T('Please complete your company and contact details first.','يرجى إكمال بيانات الشركة والتواصل أولًا.')}
document.getElementById('toStep2').onclick=()=>{checkStep1()?goStep(2):step1Fail()};
document.getElementById('toStep1').onclick=()=>goStep(1);
document.getElementById('stepper').addEventListener('click',e=>{const li=e.target.closest('li');if(!li)return;const s=+li.dataset.s;if(s===1)goStep(1);else checkStep1()?goStep(2):step1Fail()});

/* ================= RFQ SUBMIT ================= */
document.getElementById('rfqForm').addEventListener('submit',e=>{
  e.preventDefault();
  const q=id=>document.getElementById(id);const toast=q('toast');let ok=true;
  ['fName','fCompany','fEmail','fCountry','fType'].forEach(id=>{const el=q(id),bad=!el.value.trim()||(el.type==='email'&&!/^\S+@\S+\.\S+$/.test(el.value));el.parentElement.classList.toggle('err',bad);if(bad)ok=false});
  if(!ok){goStep(1);step1Fail();return}
  if(!basket.size){q('chips').classList.add('err');ok=false}
  if(!ok){toast.className='toast show bad';toast.textContent=T('Please choose at least one product.','يرجى اختيار منتج واحد على الأقل.');return}
  const prods=P.filter(p=>basket.has(p.id)).map(p=>p.en).join(', ');
  const val=id=>q(id).value||'—';
  const body=`REQUEST FOR QUOTATION — Frosty Foods\n\nContact: ${val('fName')}\nCompany: ${val('fCompany')}\nEmail: ${val('fEmail')}\nPhone: ${val('fPhone')}\nCountry: ${val('fCountry')}\nBusiness type: ${val('fType')}\n\nProducts: ${prods}\nEstimated volume: ${val('fQty')}\nIncoterm: ${val('fInco')}\nPacking: ${val('fPack')}\nDestination port: ${val('fPort')}\n\nDetails:\n${val('fMsg')}`;
  location.href=`mailto:${(window.CMS_SETTINGS&&CMS_SETTINGS.rfqEmail)||'export@frosty-foods.com'}?subject=${encodeURIComponent('RFQ — '+q('fCompany').value+' ('+q('fCountry').value+')')}&body=${encodeURIComponent(body)}`;
  toast.className='toast show ok';toast.textContent=T('Your email app is opening with the RFQ ready to send. Thank you!','يتم فتح تطبيق البريد والطلب جاهز للإرسال. شكرًا لك!');
});
document.querySelectorAll('.fld :is(input,select)').forEach(el=>el.addEventListener('input',()=>el.parentElement.classList.remove('err')));

/* ================= FAQ ================= */
let faqI=0;
function renderFaq(){
  const items=[...document.querySelectorAll('.fq')];
  items.forEach((f,i)=>{f.classList.toggle('on',i===faqI);f.querySelector('.fq-q').setAttribute('aria-expanded',i===faqI)});
  const f=items[faqI];
  document.getElementById('fpInner').innerHTML=`<div class="fp-swap"><span class="fp-count">${String(faqI+1).padStart(2,'0')} / ${String(items.length).padStart(2,'0')}</span><h3 class="fp-q">${f.querySelector('.fq-q span[data-ar]').innerHTML}</h3><p class="fp-a">${f.querySelector('.fq-a').innerHTML}</p></div>`;
}
document.getElementById('fqList').addEventListener('click',e=>{const q=e.target.closest('.fq');if(q){faqI=+q.dataset.i;renderFaq()}});

/* ================= INIT ================= */
Promise.resolve(window.CMS_BOOT).then(()=>{try{window.CMS&&CMS.apply()}catch(e){console.error('CMS apply',e)}if(window.CMS_LANG)LANG=CMS_LANG;applyLang(LANG);try{window.CMS&&CMS.afterInit()}catch(e){console.error('CMS init',e)}});
</script>
<?php wp_footer(); ?>
</body>
</html>
