=== Frosty Foods ===
Version: 1.0.0

Bilingual B2B website for Frosty Foods with a built-in dashboard.

= Dashboard =
Open the website, scroll to the footer and click "Dashboard · لوحة التحكم" (or add #dashboard to the address).
Default access code: 2026 — change it from the dashboard (SEO & settings tab).
Forgot the code? WordPress admin › Appearance › Frosty Dashboard › Reset the code.

= Where content is stored =
wp_options › frosty_content (JSON). Uploaded images/videos go to the Media Library.
